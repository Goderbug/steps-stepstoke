# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: platform.spec.ts >> historical fork copies selected output and retains original provenance
- Location: tests/e2e/platform.spec.ts:46:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('table')
Expected substring: "fx-branch-1:1"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('table') with timeout 15000ms
  - waiting for getByRole('table')

```

```yaml
- link "Skip to main content":
  - /url: "#main"
- banner:
  - link "STEPS":
    - /url: "#/"
  - navigation "Platform":
    - link "Projects":
      - /url: "#/"
    - link "Demo":
      - /url: "#/demo"
    - link "Components":
      - /url: "#/showcase"
  - button "Connect wallet"
- text: Demo mode Deterministic local fixtures. Simulated signatures only.
- group: Demo settings
- main:
  - region "Relay introduction (fork)":
    - link "← All projects":
      - /url: "#/demo"
    - heading "Relay introduction (fork)" [level=1]
    - paragraph: Build a public introduction to the relay, with a cover image and project notes.
    - paragraph: "Fork direction: Develop an accessible English introduction"
  - region "Sequence":
    - heading "Sequence" [level=2]
    - text: 1 accepted checkpoints in chain order
    - list:
      - listitem:
        - button "Select Inherited start, Latest, Selected":
          - strong: Inherited start
          - text: Snapshot inherited; no paid round Latest Selected
  - region "Inherited snapshot":
    - heading "Inherited snapshot" [level=2]
    - paragraph: Selected checkpoint · No completed paid round
    - group "Files in selected snapshot":
      - button "assets/notes.md Markdown"
      - button "assets/site.html HTML page" [pressed]
    - text: Verified locally · SHA-256, length, media
    - link "Download verified file":
      - /url: blob:http://127.0.0.1:4175/ca51d009-3d90-432c-a671-fd69ac5cb43d
    - iframe
    - group: File verification details
    - paragraph: "File origin: fx-branch-1 · checkpoint fx-branch-1:1 · producer job fx-job-1. Retained from an earlier checkpoint."
    - group: Complete asset table (2) and checkpoint evidence
  - region "What comes next?":
    - heading "What comes next?" [level=2]
    - paragraph: Prepare work at the current checkpoint, or fund an eligible contribution.
    - paragraph: Continue opens preparation only. Proposal, approval and payment stay separate.
    - button "Continue"
    - link "View contributions (0)":
      - /url: "#proposals"
  - region "Contributions":
    - heading "Contributions" [level=2]
    - text: Every eligible proposal can be funded
    - paragraph: No proposals yet. Continue opens the preparation form.
    - list
  - region "Funding and build status":
    - heading "Funding and build status" [level=2]
    - button "Refresh chain state"
    - paragraph: No funding attempts recorded for this branch.
    - list
  - group: Branch, network and execution identity
  - group: Demo failure controls (next attempt only)
- contentinfo:
  - text: STEPS · Open Workshop
  - link "Stepstoke on X":
    - /url: https://x.com/stepstoke
  - text: Release candidate · No public deployment
```

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Blocked script execution in 'about:srcdoc' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.",
+   "Blocked script execution in 'about:srcdoc' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.",
+   "Blocked script execution in 'about:srcdoc' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.",
+   "Blocked script execution in 'about:srcdoc' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.",
+   "Blocked script execution in 'about:srcdoc' because the document's frame is sandboxed and the 'allow-scripts' permission is not set.",
+ ]
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { mkdir, writeFile, readFile } from "node:fs/promises";
  3  | import { createHash } from "node:crypto";
  4  | const out="../docs/validation/platform-ux-v1/final";
  5  | const audit=new Map<string,{errors:string[];requests:string[];console:string[];expectedRequests:string[];expectedConsole:string[]}>();
  6  | test.beforeEach(async({page},info)=>{
  7  |   const row={errors:[] as string[],requests:[] as string[],console:[] as string[],expectedRequests:[] as string[],expectedConsole:[] as string[]};audit.set(info.testId,row);
  8  |   page.on("pageerror",e=>row.errors.push(e.message));page.on("console",m=>{if(m.type()==="error"){
  9  |     const expected=info.title.startsWith("Ethereum candidate has an explicit closed handoff") && new URL(m.location().url || "about:blank").pathname.endsWith("/imd-deployment.json") && /404/.test(m.text());
  10 |     (expected?row.expectedConsole:row.console).push(m.text());
  11 |   }});
  12 |   page.on("response",r=>{if(r.status()>=400){
  13 |     const expected=info.title.startsWith("Ethereum candidate has an explicit closed handoff") && r.status()===404 && new URL(r.url()).pathname.endsWith("/imd-deployment.json");
  14 |     (expected?row.expectedRequests:row.requests).push(`${r.status()} ${r.url()}`);
  15 |   }});
  16 |   await page.route(/^https?:\/\//,route=>new URL(route.request().url()).origin===new URL(info.project.use.baseURL as string).origin?route.continue():route.abort());
  17 | });
  18 | test.afterEach(async({page},info)=>{
  19 |   const row=audit.get(info.testId)!;const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth).catch(()=>-1);
  20 |   await mkdir(`${out}/raw/browser`,{recursive:true});await writeFile(`${out}/raw/browser/${info.project.name}-${info.title.replace(/[^a-z0-9]+/gi,"-").slice(0,90)}.json`,JSON.stringify({...row,overflow,status:info.status},null,2));
  21 |   if(info.title.startsWith("Ethereum candidate has an explicit closed handoff")) expect(row.expectedRequests).toHaveLength(1);
> 22 |   expect(row.errors).toEqual([]);expect(row.requests).toEqual([]);expect(row.console).toEqual([]);expect(overflow).toBe(0);
     |                                                                                       ^ Error: expect(received).toEqual(expected) // deep equality
  23 | });
  24 | async function shot(page:any,info:any,name:string){if(!["chromium-desktop","chromium-mobile"].includes(info.project.name)||name==="showcase"||(name==="funding"&&info.project.name==="chromium-desktop"))return;await mkdir(`${out}/screenshots`,{recursive:true});await page.screenshot({path:`${out}/screenshots/${info.project.name}-${name}.jpg`,type:"jpeg",quality:48,scale:"css",fullPage:false});}
  25 | async function workspace(page:any){await page.goto("./#/demo/b/fx-branch-1");await expect(page.getByRole("heading",{name:"Round 3 output"})).toBeVisible();await expect(page.getByText("Verified locally · SHA-256, length, media",{exact:true})).toBeVisible();}
  26 | async function openFunding(page:any){await workspace(page);await page.getByRole("button",{name:"Review funding",exact:true}).first().click();const sheet=page.getByRole("dialog",{name:"Fund a contribution"});await expect(sheet.getByRole("button",{name:"1. Approve exact amount"})).toBeEnabled();return sheet;}
  27 | 
  28 | test("first screen identifies the product and main action; gateway metadata",async({page},info)=>{
  29 |   await page.goto("./");await expect(page).toHaveTitle("STEPS · Stepstoke · Open Workshop");const action=page.getByRole("link",{name:/Explore demo project/});await expect(action).toBeInViewport();await expect(page.locator('html')).toHaveAttribute("lang","en");for(const name of ["description","og:title","og:image"]){expect(await page.locator(`meta[${name.startsWith("og")?"property":"name"}="${name}"]`).getAttribute("content")).toBeTruthy();}
  30 |   await shot(page,info,"home");await action.click();await expect(page.getByRole("heading",{name:"Round 3 output"})).toBeVisible();
  31 | });
  32 | test("project list and separate gas-only project creation",async({page})=>{
  33 |   await page.goto("./#/demo");await page.getByRole("button",{name:"Create project",exact:true}).click();await page.getByLabel("Project title",{exact:true}).fill("Workshop test project");await page.getByLabel("Fixed goal (cannot change after creation)").fill("Keep an exact sequence of public outputs.");await page.getByRole("button",{name:"Review creation",exact:true}).click();await expect(page.getByText("Gas only. Title and goal",{exact:false})).toBeVisible();await page.getByRole("button",{name:"Sign and create",exact:true}).dblclick();await page.getByRole("link",{name:"Open project",exact:true}).click();await expect(page.getByRole("heading",{name:"Workshop test project"})).toBeVisible();await expect(page.getByRole("heading",{name:"The first output starts here"})).toBeVisible();await expect(page.getByRole("heading",{name:"Funding and build status"})).toBeVisible();
  34 | });
  35 | test("sequence selection is read-only and exact verified downloads preserve extension",async({page},info)=>{
  36 |   await workspace(page);await shot(page,info,"workspace");await page.getByRole("button",{name:/Select Round 1/}).click();await expect(page.getByRole("heading",{name:"Round 1 output"})).toBeVisible();await expect(page.getByRole("button",{name:/Select Round 3/})).toContainText("Latest");await expect(page.getByRole("button",{name:/Select Round 1/})).toContainText("Selected");
  37 |   const [download]=await Promise.all([page.waitForEvent("download"),page.getByRole("link",{name:"Download verified file"}).click()]);expect(download.suggestedFilename()).toBe("notes.md");const bytes=await readFile((await download.path())!);const expected=await page.evaluate(()=>{const data=JSON.parse(localStorage.getItem("platform.fixture.v1")!);return data.checkpoints.find((c:any)=>c.id==="fx-branch-1:1").assets.find((a:any)=>a.assetKey==="notes").descriptor.sha256;});expect(`0x${createHash("sha256").update(bytes).digest("hex")}`).toBe(expected);
  38 |   await page.getByRole("button",{name:"Continue",exact:true}).click();const sheet=page.getByRole("dialog",{name:"Prepare a contribution"});await expect(sheet).toContainText("fx-branch-1:3");await expect(sheet.getByRole("button",{name:"Sign and submit proposal"})).toHaveCount(0);await page.keyboard.press("Escape");await expect(page.getByRole("button",{name:"Continue",exact:true})).toBeFocused();
  39 | });
  40 | test("continue prepares a proposal without approval or purchase",async({page})=>{
  41 |   await workspace(page);await page.getByRole("button",{name:"Continue",exact:true}).click();const form=page.getByRole("dialog");await form.getByLabel("New asset name",{exact:true}).fill("guide");await form.getByLabel("Requirement",{exact:true}).fill("Document the handoff in plain English.");await form.getByRole("button",{name:"Review proposal",exact:true}).click();await expect(form).toContainText("Gas only. Execution requires separate funding");await form.getByRole("button",{name:"Sign and submit proposal"}).click();await expect(form).toHaveCount(0);await expect(page.getByRole("heading",{name:/Create Markdown.*guide/})).toBeVisible();expect(await page.evaluate(()=>JSON.parse(localStorage.getItem("platform.fixture.v1")!).sponsorships.length)).toBe(0);expect(await page.getByRole("button",{name:"Review funding",exact:true}).count()).toBe(3);
  42 | });
  43 | test("approval confirms before a separate purchase; exact allowance; completed attempt",async({page},info)=>{
  44 |   const sheet=await openFunding(page);await shot(page,info,"funding");await expect(sheet.getByRole("button",{name:"2. Purchase execution"})).toBeDisabled();await sheet.getByLabel(/Maximum fee/).fill("100");await sheet.getByRole("button",{name:"1. Approve exact amount"}).dblclick();await expect(sheet.getByRole("button",{name:"2. Purchase execution"})).toBeEnabled();expect(await page.evaluate(()=>Object.values(JSON.parse(localStorage.getItem("platform.fixture.v1")!).allowances))).toEqual(["25000000000000000000"]);await sheet.getByRole("button",{name:"2. Purchase execution"}).dblclick();await expect(sheet).toHaveCount(0);await expect(page.locator(".attempt")).toHaveCount(1);await expect(page.locator(".attempt .stage").filter({hasText:"Binding"})).toContainText("Confirmed");await page.getByRole("button",{name:/Select Round 4/}).click();await expect(page.getByRole("heading",{name:"Round 4 output"})).toBeVisible();await expect(page.getByRole("button",{name:/Select Round 3/})).not.toContainText("Latest");
  45 | });
  46 | test("historical fork copies selected output and retains original provenance",async({page})=>{
  47 |   await workspace(page);await page.getByRole("button",{name:/Select Round 1/}).click();await page.getByRole("button",{name:"Historical Fork",exact:true}).click();const sheet=page.getByRole("dialog",{name:"Historical Fork"});await expect(sheet).toContainText("fx-branch-1:1");await sheet.getByLabel("Fork direction (fixed after creation)").fill("Develop an accessible English introduction");await sheet.getByRole("button",{name:"Review fork"}).click();await sheet.getByRole("button",{name:"Sign and fork"}).click();await sheet.getByRole("link",{name:"Open fork",exact:true}).click();await expect(page.getByRole("heading",{name:"Inherited snapshot"})).toBeVisible();await expect(page.getByRole("button",{name:"Historical Fork",exact:true})).toHaveCount(0);await page.getByText(/Complete asset table/).click();await expect(page.getByRole("table")).toContainText("fx-branch-1:1");await expect(page.getByRole("table")).toContainText("fx-job-1");expect(await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem("platform.fixture.v1")!);return s.branches.find((b:any)=>b.id===location.hash.split("/").at(-1)).imdProjectId;})).toBeNull();
  48 | });
  49 | test("PNG uses its natural aspect ratio and all original file origins remain reachable",async({page})=>{
  50 |   await workspace(page);await page.getByRole("button",{name:/Select Round 2/}).click();const image=page.locator(".img-box img");await expect(image).toBeVisible();const size=await image.evaluate((i:HTMLImageElement)=>({w:i.getBoundingClientRect().width,h:i.getBoundingClientRect().height,nw:i.naturalWidth,nh:i.naturalHeight}));expect(size.w/size.h).toBeCloseTo(size.nw/size.nh,4);await page.getByText(/Complete asset table/).click();await expect(page.getByRole("table")).toContainText("fx-job-1");await expect(page.getByRole("table")).toContainText("fx-job-2");
  51 | });
  52 | test("isolated HTML and sanitized Markdown; bad and unavailable files never verified",async({page})=>{
  53 |   await page.goto("./#/demo/b/fx-branch-sec");await expect(page.locator("iframe")).toHaveAttribute("sandbox","");const frame=page.locator("iframe").contentFrame();await expect(frame.locator("script,form,iframe,[href],[action],img[src]")).toHaveCount(0);await page.getByRole("button",{name:/assets\/evil-notes.md/}).click();await expect(page.locator(".md")).toBeVisible();await expect(page.locator(".md script,.md iframe,.md img,[autofocus]")).toHaveCount(0);for(const name of ["tampered.png","missing.md","fake-png.png","broken-png.png","oversized-png.png"]){await page.getByRole("button",{name:new RegExp(`assets/${name.replace('.','\\.')}`)}).click();await expect(page.locator(".preview [role=alert]")).toBeVisible();await expect(page.locator(".preview .badge-ok")).toHaveCount(0);await expect(page.getByRole("link",{name:"Download verified file"})).toHaveCount(0);}
  54 | });
  55 | test("account changes cancel preparation; wrong network disables signing",async({page})=>{
  56 |   await openFunding(page);await page.keyboard.press("Escape");await page.getByText("Demo settings",{exact:true}).click();await page.getByLabel("Simulate wrong network").check();await expect(page.getByRole("button",{name:"Review funding",exact:true}).first()).toBeDisabled();await page.getByLabel("Simulate wrong network").uncheck();await page.getByText("Demo settings",{exact:true}).click();await page.getByRole("button",{name:"Review funding",exact:true}).first().click();await page.keyboard.press("Escape");await page.getByText("Demo settings",{exact:true}).click();await page.getByLabel("Demo signing account").selectOption("1");await expect(page.getByRole("status")).toContainText("Account or network changed");
  57 | });
  58 | test("production-component showcase and wallet sheet keyboard focus",async({page},info)=>{
  59 |   await page.goto("./#/showcase");await expect(page.getByRole("heading",{name:"Platform components",exact:true})).toBeVisible();await expect(page.getByRole("heading",{name:"Round 3 output"})).toBeVisible();await page.getByRole("button",{name:"Review demo funding"}).click();await expect(page.getByRole("dialog")).toBeVisible();await page.keyboard.press("Tab");await expect(page.getByRole("button",{name:"Close preparation"})).toBeFocused();await page.keyboard.press("Escape");await expect(page.getByRole("button",{name:"Review demo funding"})).toBeFocused();await page.getByRole("button",{name:"Connect wallet",exact:true}).click();const wallet=page.getByRole("dialog",{name:"Connect wallet"});await expect(wallet).toBeVisible();await expect(wallet.getByText("Injected",{exact:true})).toHaveCount(0);await page.keyboard.press("Escape");await expect(page.getByRole("button",{name:"Connect wallet",exact:true})).toBeFocused();await shot(page,info,"showcase");
  60 | });
  61 | 
  62 | test("reduced motion keeps keyboard preparation, focus return and historical selection usable",async({page})=>{
  63 |   await page.emulateMedia({reducedMotion:"reduce"});await workspace(page);
  64 |   const action=page.getByRole("button",{name:"Continue",exact:true});
  65 |   expect(await action.evaluate(el=>getComputedStyle(el).transitionDuration)).toBe("0s");
  66 |   await action.focus();await page.keyboard.press("Enter");const sheet=page.getByRole("dialog",{name:"Prepare a contribution"});
  67 |   await page.keyboard.press("Tab");await expect(sheet.getByRole("button",{name:"Close preparation"})).toBeFocused();
  68 |   await page.keyboard.press("Shift+Tab");await expect(sheet.getByRole("button",{name:"Review proposal",exact:true})).toBeFocused();
  69 |   await page.keyboard.press("Escape");await expect(action).toBeFocused();
  70 |   await page.getByRole("button",{name:/Select Round 1/}).click();await expect(page.getByRole("button",{name:/Select Round 3/})).toContainText("Latest");
  71 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth-innerWidth)).toBe(0);
  72 | });
  73 | 
  74 | test("Ethereum candidate has an explicit closed handoff without fabricated addresses",async({page})=>{
  75 |  await page.goto('./#/ethereum');
  76 |  await expect(page.getByRole('heading',{name:'Ethereum deployment unavailable'})).toBeVisible();
  77 |  await expect(page.getByText('Confirmed deployment handoff unavailable')).toBeVisible();
  78 |  await expect(page.getByRole('button',{name:'Verify configuration again'})).toBeVisible();
  79 |  await expect(page.getByRole('button',{name:'Create project'})).toHaveCount(0);
  80 | });
  81 | 
  82 | // Disposable diagnostic instrumentation; not a product/test repair.
  83 | test.beforeEach(async({page})=>{await page.addInitScript(()=>{
  84 |  const rows:any[]=[];(window as any).__revisionEvents=rows;
  85 |  const save=(type:string,e:any)=>{const target=e.target instanceof Element?e.target:null;rows.push({type,time:performance.now(),target:target?.tagName,text:target?.closest('button,summary')?.textContent?.slice(0,100),x:e.clientX,y:e.clientY,pending:!!document.querySelector('#assets .state-line'),details:[...document.querySelectorAll('details')].map(d=>({name:d.querySelector('summary')?.textContent,open:d.open})),active:document.activeElement?.tagName});if(rows.length>250)rows.shift();};
  86 |  for(const type of ['pointerdown','pointerup','mousedown','mouseup','click','toggle'])document.addEventListener(type,e=>save(type,e),true);
  87 | });});
  88 | test.afterEach(async({page},info)=>{await mkdir('../evidence/debug-events',{recursive:true});await writeFile('../evidence/debug-events/'+info.project.name+'-'+info.repeatEachIndex+'-'+info.title.slice(0,18).replace(/[^a-z]/gi,'-')+'.json',JSON.stringify(await page.evaluate(()=>({rows:(window as any).__revisionEvents,scrollY,frame:document.querySelector('.frame')?.getBoundingClientRect().toJSON(),pending:!!document.querySelector('#assets .state-line')})).catch(()=>null),null,2));});
  89 | 
```