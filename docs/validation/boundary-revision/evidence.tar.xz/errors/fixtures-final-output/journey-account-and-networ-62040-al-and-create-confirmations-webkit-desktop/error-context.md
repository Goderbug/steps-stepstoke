# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: journey.spec.ts >> account and network changes invalidate proposal and create confirmations
- Location: tests/e2e/journey.spec.ts:159:1

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.fill: Test timeout of 45000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Prepare a contribution' }).getByLabel('New asset name')

```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - link "Skip to main content" [ref=f1e3]:
    - /url: "#main"
  - banner [ref=f1e4]:
    - link "STEPS" [ref=f1e5]:
      - /url: "#/"
    - navigation "Platform" [ref=f1e7]:
      - link "Projects" [ref=f1e8]:
        - /url: "#/"
      - link "Demo" [ref=f1e9]:
        - /url: "#/demo"
      - link "Components" [ref=f1e10]:
        - /url: "#/showcase"
    - button "Connect wallet" [ref=f1e12] [cursor=pointer]
  - generic [ref=f1e13]:
    - generic [ref=f1e14]: Demo mode
    - generic [ref=f1e15]: Deterministic local fixtures. Simulated signatures only.
    - group [ref=f1e16]:
      - generic "Demo settings" [ref=f1e17] [cursor=pointer]
      - generic [ref=f1e18]:
        - generic [ref=f1e19]:
          - generic [ref=f1e20]: Demo signing account
          - combobox "Demo signing account" [ref=f1e21]:
            - option "Demo account A"
            - option "Demo account B" [selected]
        - generic [ref=f1e22] [cursor=pointer]:
          - checkbox "Simulate wrong network" [ref=f1e23]
          - generic [ref=f1e24]: Simulate wrong network
        - button "Reset demo data" [ref=f1e25] [cursor=pointer]
  - main [ref=f1e26]:
    - generic [ref=f1e27]:
      - region [ref=f1e28]:
        - link "← All projects" [ref=f1e29]:
          - /url: "#/demo"
        - heading "Relay introduction" [level=1] [ref=f1e31]
        - paragraph [ref=f1e32]: Build a public introduction to the relay, with a cover image and project notes.
      - region [ref=f1e33]:
        - generic [ref=f1e34]:
          - heading "Sequence" [level=2] [ref=f1e35]
          - generic [ref=f1e36]: 4 accepted checkpoints in chain order
        - list [ref=f1e37]:
          - listitem [ref=f1e38]:
            - button "Select Project created" [ref=f1e39] [cursor=pointer]:
              - generic [ref=f1e40]: "00"
              - generic [ref=f1e41]:
                - strong [ref=f1e42]: Project created
                - generic [ref=f1e43]: Fixed goal; no paid round
          - listitem [ref=f1e44]:
            - button "Select Round 1" [ref=f1e45] [cursor=pointer]:
              - generic [ref=f1e46]: "01"
              - generic [ref=f1e47]:
                - strong [ref=f1e48]: Round 1
                - generic [ref=f1e49]: HTML page + Markdown
          - listitem [ref=f1e50]:
            - button "Select Round 2" [ref=f1e51] [cursor=pointer]:
              - generic "Verified local thumbnail" [ref=f1e52]:
                - img "Verified PNG thumbnail" [ref=f1e53]
              - generic [ref=f1e54]: "02"
              - generic [ref=f1e55]:
                - strong [ref=f1e56]: Round 2
                - generic [ref=f1e57]: PNG image
          - listitem [ref=f1e58]:
            - button "Select Round 3, Latest, Selected" [ref=f1e59] [cursor=pointer]:
              - generic [ref=f1e60]: "03"
              - generic [ref=f1e61]:
                - strong [ref=f1e62]: Round 3
                - generic [ref=f1e63]: HTML page
              - generic [ref=f1e64]:
                - generic [ref=f1e65]: Latest
                - generic [ref=f1e66]: Selected
      - region [ref=f1e67]:
        - generic [ref=f1e68]:
          - generic [ref=f1e69]:
            - heading "Round 3 output" [level=2] [ref=f1e70]
            - paragraph [ref=f1e71]: Selected checkpoint · Accepted execution
          - button "Historical Fork" [ref=f1e72] [cursor=pointer]
        - group "Files in selected snapshot" [ref=f1e73]:
          - button "assets/notes.md Markdown" [ref=f1e74] [cursor=pointer]:
            - text: assets/notes.md
            - generic [ref=f1e75]: Markdown
          - button "assets/cover.png PNG image" [ref=f1e76] [cursor=pointer]:
            - text: assets/cover.png
            - generic [ref=f1e77]: PNG image
          - button "assets/site.html HTML page" [pressed] [ref=f1e78] [cursor=pointer]:
            - text: assets/site.html
            - generic [ref=f1e79]: HTML page
        - generic [ref=f1e80]:
          - generic [ref=f1e81]:
            - generic [ref=f1e82]: Verified locally · SHA-256, length, media
            - link "Download verified file" [ref=f1e83]:
              - /url: blob:http://127.0.0.1:4175/784d62a5-8d9c-48d3-83c9-a2056dbec06e
          - iframe [ref=f1e84]:
            - generic [ref=f2e1]:
              - heading "Introducing CTO Relay" [level=1] [ref=f2e2]
              - paragraph [ref=f2e3]: A public introduction built in round one.
              - paragraph [ref=f2e4]: "Round three includes the cover from round two:"
              - img "Cover from round two" [ref=f2e5]
          - group [ref=f1e85]:
            - generic "File verification details" [ref=f1e86] [cursor=pointer]
        - paragraph [ref=f1e87]: "File origin: fx-branch-1 · checkpoint fx-branch-1:3 · producer job fx-job-3. Changed in this checkpoint."
        - group [ref=f1e88]:
          - generic "Complete asset table (3) and checkpoint evidence" [ref=f1e89] [cursor=pointer]
      - region [ref=f1e90]:
        - generic [ref=f1e91]:
          - heading "What comes next?" [level=2] [ref=f1e92]
          - paragraph [ref=f1e93]: Prepare work at the current checkpoint, or fund an eligible contribution.
          - paragraph [ref=f1e94]: Continue opens preparation only. Proposal, approval and payment stay separate.
        - generic [ref=f1e95]:
          - button "Continue" [active] [ref=f1e96] [cursor=pointer]
          - link "View contributions (2)" [ref=f1e97]:
            - /url: "#proposals"
      - region [ref=f1e98]:
        - generic [ref=f1e99]:
          - heading "Contributions" [level=2] [ref=f1e100]
          - generic [ref=f1e101]: Every eligible proposal can be funded
        - list [ref=f1e102]:
          - listitem [ref=f1e103]:
            - article [ref=f1e104]:
              - generic [ref=f1e105]:
                - heading "Update Markdown · notes" [level=3] [ref=f1e106]:
                  - text: Update Markdown
                  - generic [ref=f1e107]: · notes
                - generic [ref=f1e108]: Eligible
              - paragraph [ref=f1e109]: Expand the notes with the project goal, how to fund work and how to fork.
              - group [ref=f1e110]:
                - generic "Proposal details" [ref=f1e111] [cursor=pointer]
              - button "Review funding" [ref=f1e112] [cursor=pointer]
          - listitem [ref=f1e113]:
            - article [ref=f1e114]:
              - generic [ref=f1e115]:
                - heading "Update HTML page · site" [level=3] [ref=f1e116]:
                  - text: Update HTML page
                  - generic [ref=f1e117]: · site
                - generic [ref=f1e118]: Eligible
              - paragraph [ref=f1e119]: Improve the introduction while keeping the cover and the original round marker.
              - group [ref=f1e120]:
                - generic "Proposal details" [ref=f1e121] [cursor=pointer]
              - button "Review funding" [ref=f1e122] [cursor=pointer]
          - listitem [ref=f1e123]:
            - article [ref=f1e124]:
              - generic [ref=f1e125]:
                - heading "Create PNG image · banner" [level=3] [ref=f1e126]:
                  - text: Create PNG image
                  - generic [ref=f1e127]: · banner
                - generic [ref=f1e128]: Stale anchor
              - paragraph [ref=f1e129]: Create a banner image.
              - group [ref=f1e130]:
                - generic "Proposal details" [ref=f1e131] [cursor=pointer]
              - button "Prepare at current checkpoint" [ref=f1e132] [cursor=pointer]
      - region [ref=f1e133]:
        - generic [ref=f1e134]:
          - heading "Funding and build status" [level=2] [ref=f1e135]
          - button "Refresh chain state" [ref=f1e136] [cursor=pointer]
        - paragraph [ref=f1e137]: No funding attempts recorded for this branch.
        - list
      - group [ref=f1e138]:
        - generic "Branch, network and execution identity" [ref=f1e139] [cursor=pointer]
      - group [ref=f1e140]:
        - generic "Demo failure controls (next attempt only)" [ref=f1e141] [cursor=pointer]
        - option "Accept and bind" [selected]
        - option "Missing; remain pending"
        - option "Refused; status 1"
        - option "Frozen; status 2"
        - option "Accepted; invalid binding"
        - option "Confirmed" [selected]
        - option "Unknown; reconcile"
  - contentinfo [ref=f1e142]:
    - generic [ref=f1e143]: STEPS · Open Workshop
    - link "Stepstoke on X" [ref=f1e144]:
      - /url: https://x.com/stepstoke
    - generic [ref=f1e145]: Release candidate · No public deployment
```

# Test source

```ts
  70  | 
  71  |   const evidence: object[] = [];
  72  |   await mkdir("../docs/validation/platform-ux-v1/final/fixtures/files", { recursive: true });
  73  |   const download = async (key: string, revision: number, ext: string) => {
  74  |     const row = page.locator("#assets");
  75  |     await selectFile(page, key);
  76  |     await expect(row.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  77  |     const pending = page.waitForEvent("download");
  78  |     await row.getByRole("link", { name: "Download verified file" }).click();
  79  |     const d = await pending;
  80  |     const path = `../docs/validation/platform-ux-v1/final/fixtures/files/${info.project.name}-${key}-r${revision}.${ext}`;
  81  |     await d.saveAs(path);
  82  |     const bytes = await readFile(path);
  83  |     const sha256 = `0x${createHash("sha256").update(bytes).digest("hex")}`;
  84  |     await expect(row).toContainText(sha256);
  85  |     const stored = await page.evaluate(({ branchId, key }) => {
  86  |       const state = JSON.parse(localStorage.getItem("platform.fixture.v1")!);
  87  |       const branch = state.branches.find((b: { id: string }) => b.id === branchId);
  88  |       return state.checkpoints.find((c: { id: string }) => c.id === branch.latestCheckpoint).assets.find((a: { assetKey: string }) => a.assetKey === key);
  89  |     }, { branchId: page.url().split("/b/")[1], key });
  90  |     expect(bytes.length).toBe(stored.descriptor.bytes);
  91  |     expect(sha256).toBe(stored.descriptor.sha256);
  92  |     evidence.push({ file: path, sha256, bytes: bytes.length, producerJob: stored.producerJobId, assetRevision: stored.revision, provenance: stored.originCheckpoint });
  93  |     return bytes;
  94  |   };
  95  |   const r1 = await download("landing", 1, "html");
  96  |   expect(r1.toString()).toContain("marker:R1");
  97  |   await propose(page, "image", "cover", "Generate one cover image.");
  98  |   await identity(page, "Demo signing account", "0");
  99  |   await sponsor(page, "Create PNG image · cover", `fx-job-${branchId}-1`);
  100 |   await selectRound(page, 2);
  101 |   await expect(page.getByRole("heading", { name: "Round 2 output", exact: true })).toBeVisible();
  102 |   const cover = await download("cover", 2, "png");
  103 |   expect(cover.toString("base64")).toBe(PNG_AMBER_B64);
  104 |   await expect(page.getByRole("img", { name: "cover from round 2" })).toBeVisible();
  105 | 
  106 |   await propose(page, "html", "landing", "Use first round HTML and second round PNG; retain original markers.", true, ["cover"]);
  107 |   const p = page.locator("#proposals > ul > li", { hasText: "Update HTML page · landing" });
  108 |   await disclose(page, /^Proposal details/);
  109 |   await expect(p).toContainText("landing@1");
  110 |   await expect(p).toContainText("cover@2");
  111 |   await identity(page, "Demo signing account", "1");
  112 |   await sponsor(page, "Update HTML page · landing", `fx-job-${branchId}-2`);
  113 |   await selectRound(page, 3);
  114 |   await expect(page.getByRole("heading", { name: "Round 3 output", exact: true })).toBeVisible();
  115 |   const r3 = await download("landing", 3, "html");
  116 |   expect(r3.toString()).toContain("marker:R1");
  117 |   expect(r3.toString()).toContain("marker:R3");
  118 |   expect(r3.toString()).toContain(`data:image/png;base64,${cover.toString("base64")}`);
  119 |   expect(r3.equals(r1)).toBe(false);
  120 |   await expect(page.frameLocator("iframe.frame").locator("img")).toHaveAttribute("src", `data:image/png;base64,${cover.toString("base64")}`);
  121 | 
  122 |   await propose(page, "document", "guide", "Explain funding and forks.");
  123 |   await sponsor(page, "Create Markdown · guide", `fx-job-${branchId}-3`);
  124 |   await selectRound(page, 4);
  125 |   await expect(page.getByRole("heading", { name: "Round 4 output", exact: true })).toBeVisible();
  126 |   const md = await download("guide", 4, "md");
  127 |   expect(md.toString()).toContain("# guide");
  128 |   await disclose(page, /^Complete asset table/);
  129 |   await expect(page.locator("#assets")).toContainText("landing@3");
  130 |   await expect(page.locator("#assets")).toContainText("cover@2");
  131 |   await expect(page.locator("#progress > ul > li")).toHaveCount(4);
  132 |   // A historical R1 fork copies only its R1 HTML, even though the parent now has R4 assets.
  133 |   await selectRound(page, 1);
  134 |   const historic = page.getByRole("dialog", { name: "Historical Fork" });
  135 |   await page.getByRole("button", { name: "Historical Fork", exact: true }).click();
  136 |   await historic.getByLabel("Fork direction (fixed after creation)").fill("Start from round one without later images or notes.");
  137 |   await historic.getByRole("button", { name: "Review fork" }).click();
  138 |   await historic.getByRole("button", { name: "Sign and fork" }).dblclick();
  139 |   await historic.getByRole("link", { name: "Open fork" }).click();
  140 |   await disclose(page, /^Branch, network/);
  141 |   await expect(page.getByText("None / None")).toBeVisible();
  142 |   await disclose(page, /^Complete asset table/);
  143 |   await expect(page.locator("#assets tbody tr")).toHaveCount(1);
  144 |   await expect(page.getByText("No proposals yet", { exact: false })).toBeVisible();
  145 |   const forked = await download("landing", 0, "html");
  146 |   expect(forked.equals(r1)).toBe(true);
  147 |   await expect(page.locator("#assets")).toContainText(`File origin: ${branchId}`);
  148 |   await expect(page.locator("#progress > ul > li")).toHaveCount(0);
  149 |   await propose(page, "document", "child-guide", "Independent child execution.");
  150 |   const childRow = page.locator("#proposals > ul > li", { hasText: "Create Markdown · child-guide" });
  151 |   await childRow.getByRole("button", { name: "Review funding" }).click();
  152 |   await disclose(page, /^Exact proposal/);
  153 |   await expect(funding(page)).toContainText("job.open / None; first execution");
  154 |   expect(await page.evaluate(() => (window as unknown as { __walletCalls: string[] }).__walletCalls)).toEqual([]);
  155 |   await writeFile(`../docs/validation/platform-ux-v1/final/fixtures/files/${info.project.name}-journey.json`, JSON.stringify({ mode: "fixture-only", realWalletRequests: [], checks: "Six flows; four executed rounds; exact retained HTML/PNG; historical R1 fork; independent Node SHA-256 checks", files: evidence }, null, 2));
  156 |   await page.screenshot({ scale: "css", path: `../test/scratch/regression-screenshots/${info.project.name}-historical-fork.jpg`, type: "jpeg", quality: 50 });
  157 | });
  158 | 
  159 | test("account and network changes invalidate proposal and create confirmations", async ({ page }) => {
  160 |   await demo(page);
  161 |   await page.getByRole("button", { name: "Create project", exact: true }).click();
  162 |   await page.getByLabel("Project title", { exact: true }).fill("Previous account preview");
  163 |   await page.getByLabel("Fixed goal (cannot change after creation)").fill("Fixed goal");
  164 |   await page.getByRole("button", { name: "Review creation" }).click();
  165 |   await expect(page.getByRole("button", { name: "Sign and create" })).toBeVisible();
  166 |   await identity(page, "Demo signing account", "1");
  167 |   await expect(page.getByRole("button", { name: "Sign and create" })).toHaveCount(0);
  168 |   await page.goto("./#/demo/b/fx-branch-1");
  169 |   await prepare(page);
> 170 |   await form(page).getByLabel("New asset name").fill("new-slot");
      |                                                 ^ Error: locator.fill: Test timeout of 45000ms exceeded.
  171 |   await form(page).getByRole("textbox", { name: /^Requirement/ }).fill("Previous network proposal");
  172 |   await form(page).getByRole("button", { name: "Review proposal" }).click();
  173 |   await expect(page.getByRole("button", { name: "Sign and submit proposal" })).toBeVisible();
  174 |   await identity(page, "Simulate wrong network", true);
  175 |   await expect(page.getByRole("button", { name: "Sign and submit proposal" })).toHaveCount(0);
  176 | });
  177 | 
  178 | test("resetting the demo clears cached projects and prepared forms from the project list", async ({ page }) => {
  179 |   await demo(page);
  180 |   await page.getByRole("button", { name: "Create project", exact: true }).click();
  181 |   await page.getByLabel("Project title", { exact: true }).fill("Reset cache project");
  182 |   await page.getByLabel("Fixed goal (cannot change after creation)").fill("This demo project disappears on reset.");
  183 |   await page.getByRole("button", { name: "Review creation" }).click();
  184 |   await page.getByRole("button", { name: "Sign and create" }).click();
  185 |   await expect(page.getByRole("link", { name: "Reset cache project", exact: true })).toBeVisible();
  186 |   await page.getByRole("button", { name: "Reset demo data", exact: true }).dblclick();
  187 |   await expect(page.getByRole("link", { name: "Reset cache project", exact: true })).toHaveCount(0);
  188 |   await expect(page.getByRole("heading", { name: "Create a project", exact: true })).toHaveCount(0);
  189 |   await expect(page.getByRole("link", { name: "Relay introduction", exact: true })).toBeVisible();
  190 |   await expect(page.locator(".list > li")).toHaveCount(2);
  191 | });
  192 | 
  193 | test("preview navigation, forms, wallet messages and storage are inert; version changes do not reuse verified bytes", async ({ page }) => {
  194 |   await demo(page, "#/demo/b/fx-branch-sec");
  195 |   await page.evaluate(() => { (window as unknown as { __previewMessages: unknown[] }).__previewMessages = []; window.addEventListener("message", (event) => (window as unknown as { __previewMessages: unknown[] }).__previewMessages.push(event.data)); });
  196 |   await selectFile(page, "evil-site");
  197 |   const frame = page.frameLocator("iframe.frame");
  198 |   await expect(frame.locator("#evil")).toHaveText("Hostile HTML fixture");
  199 |   await expect(frame.locator("script, form, input, button, iframe, [href], meta[http-equiv='refresh']")).toHaveCount(0);
  200 |   await frame.getByText("Top navigation attempt").click();
  201 |   expect(page.url()).toContain("#/demo/b/fx-branch-sec");
  202 |   expect(page.context().pages()).toHaveLength(1);
  203 |   expect(await page.evaluate(() => ({ messages: (window as unknown as { __previewMessages: unknown[] }).__previewMessages, storage: localStorage.getItem("w1.pwned") }))).toEqual({ messages: [], storage: null });
  204 |   expect(await page.locator("iframe.frame").evaluate((node) => { try { return (node as HTMLIFrameElement).contentWindow?.localStorage.length; } catch { return "SecurityError"; } })).toBe("SecurityError");
  205 |   await page.goto("./#/demo/b/fx-branch-1");
  206 |   const site = () => page.locator("#assets");
  207 |   await selectFile(page, "site");
  208 |   await expect(site().getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  209 |   await page.getByRole("button", { name: /^Select Round 1(?:,|$)/ }).click();
  210 |   await selectFile(page, "site");
  211 |   await expect(site()).toContainText("site@1");
  212 |   await expect(page.frameLocator("iframe.frame").locator("img")).toHaveCount(0);
  213 |   await expect(page.frameLocator("iframe.frame").locator("h1")).toHaveText("Introducing CTO Relay");
  214 | });
  215 | 
```