# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: revision.spec.ts >> sponsorship progress shows the complete purchase hash and sponsor with copy controls
- Location: tests/e2e/revision.spec.ts:88:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#progress > ul > li').first().getByRole('button', { name: 'Copy transaction hash' })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#progress > ul > li').first().getByRole('button', { name: 'Copy transaction hash' }) with timeout 15000ms
  - waiting for locator('#progress > ul > li').first().getByRole('button', { name: 'Copy transaction hash' })

```

```yaml
- link "Skip to main content":
  - /url: "#main"
- banner:
  - link "STEPS":
    - /url: "#/"
  - navigation "Platform":
    - link "Projects":
      - /url: "#/"
    - link "Demo":
      - /url: "#/demo"
    - link "Components":
      - /url: "#/showcase"
  - button "Connect wallet"
- text: Demo mode Deterministic local fixtures. Simulated signatures only.
- group:
  - text: Demo settings Demo signing account
  - combobox "Demo signing account":
    - option "Demo account A" [selected]
    - option "Demo account B"
  - checkbox "Simulate wrong network"
  - text: Simulate wrong network
  - button "Reset demo data"
- main:
  - region "Relay introduction":
    - link "← All projects":
      - /url: "#/demo"
    - heading "Relay introduction" [level=1]
    - paragraph: Build a public introduction to the relay, with a cover image and project notes.
  - region "Sequence":
    - heading "Sequence" [level=2]
    - text: 4 accepted checkpoints in chain order
    - list:
      - listitem:
        - button "Select Project created":
          - strong: Project created
          - text: Fixed goal; no paid round
      - listitem:
        - button "Select Round 1":
          - strong: Round 1
          - text: HTML page + Markdown
      - listitem:
        - button "Select Round 2":
          - img "Verified PNG thumbnail"
          - strong: Round 2
          - text: PNG image
      - listitem:
        - button "Select Round 3, Latest, Selected":
          - strong: Round 3
          - text: HTML page Latest Selected
  - region "Round 3 output":
    - heading "Round 3 output" [level=2]
    - paragraph: Selected checkpoint · Accepted execution
    - button "Historical Fork"
    - group "Files in selected snapshot":
      - button "assets/notes.md Markdown"
      - button "assets/cover.png PNG image"
      - button "assets/site.html HTML page" [pressed]
    - text: Verified locally · SHA-256, length, media
    - link "Download verified file":
      - /url: blob:http://127.0.0.1:4175/340adab4-a3ff-4e40-b34a-05178669c77a
    - iframe
    - group: File verification details
    - paragraph: "File origin: fx-branch-1 · checkpoint fx-branch-1:3 · producer job fx-job-3. Changed in this checkpoint."
    - group:
      - text: Complete asset table (3) and checkpoint evidence
      - paragraph: The latest execution is not the origin of every file. Select any file above to verify its exact bytes.
      - region "Asset provenance table":
        - table:
          - rowgroup:
            - row "File / version Original branch Original checkpoint Producer job Descriptor":
              - columnheader "File / version"
              - columnheader "Original branch"
              - columnheader "Original checkpoint"
              - columnheader "Producer job"
              - columnheader "Descriptor"
          - rowgroup:
            - row "assets/notes.md notes@1 fx-branch-1 fx-branch-1:1 fx-job-1 152 bytes text/markdown 0x5b2d051b5387d56a31dbb74d5ae99fe36efb6f77bf40a510dfa1c4c563fec747 Copy notes SHA-256":
              - rowheader "assets/notes.md notes@1"
              - cell "fx-branch-1"
              - cell "fx-branch-1:1"
              - cell "fx-job-1"
              - cell "152 bytes text/markdown 0x5b2d051b5387d56a31dbb74d5ae99fe36efb6f77bf40a510dfa1c4c563fec747 Copy notes SHA-256":
                - text: 152 bytes text/markdown
                - code: "0x5b2d051b5387d56a31dbb74d5ae99fe36efb6f77bf40a510dfa1c4c563fec747"
                - button "Copy notes SHA-256": Copy
            - row "assets/cover.png cover@2 fx-branch-1 fx-branch-1:2 fx-job-2 87 bytes image/png 0xc9d4eb7fbdd6362e6cf57c114055039222f2487d4e40ea5ad20334f58597e1cc Copy cover SHA-256":
              - rowheader "assets/cover.png cover@2"
              - cell "fx-branch-1"
              - cell "fx-branch-1:2"
              - cell "fx-job-2"
              - cell "87 bytes image/png 0xc9d4eb7fbdd6362e6cf57c114055039222f2487d4e40ea5ad20334f58597e1cc Copy cover SHA-256":
                - text: 87 bytes image/png
                - code: "0xc9d4eb7fbdd6362e6cf57c114055039222f2487d4e40ea5ad20334f58597e1cc"
                - button "Copy cover SHA-256": Copy
            - row "assets/site.html site@3 fx-branch-1 fx-branch-1:3 fx-job-3 617 bytes text/html 0x37c2e0e0ee9dfa9ccb4ed5de4d7392c628cdb4003d1231855cefe9e9ed83f5fd Copy site SHA-256":
              - rowheader "assets/site.html site@3"
              - cell "fx-branch-1"
              - cell "fx-branch-1:3"
              - cell "fx-job-3"
              - cell "617 bytes text/html 0x37c2e0e0ee9dfa9ccb4ed5de4d7392c628cdb4003d1231855cefe9e9ed83f5fd Copy site SHA-256":
                - text: 617 bytes text/html
                - code: "0x37c2e0e0ee9dfa9ccb4ed5de4d7392c628cdb4003d1231855cefe9e9ed83f5fd"
                - button "Copy site SHA-256": Copy
      - term: Checkpoint
      - definition:
        - code: fx-branch-1:3
        - button "Copy checkpoint ID": Copy
      - term: Execution job
      - definition: fx-job-3
      - term: Funder
      - definition: "0x2c596e12dBB8A46D7700f586e5f793aD483a76b4"
      - term: Manifest keccak256
      - definition:
        - code: "0x51e9490a9f845968a645bdcc41a2d2aa7b43d203579a60ebc3bea2a7b791133f"
        - button "Copy manifest keccak256": Copy
      - term: Git / publication
      - definition:
        - text: observed / pending. External URLs do not establish acceptance.
        - link "View Git evidence":
          - /url: https://github.com/imd-fixture/relay-demo/commit/r3
        - link "View publication evidence":
          - /url: https://relay-demo.example.org/
  - region "What comes next?":
    - heading "What comes next?" [level=2]
    - paragraph: An attempt is unresolved. Review its status before funding again.
    - paragraph: Continue opens preparation only. Proposal, approval and payment stay separate.
    - button "Continue"
    - link "View contributions (1)":
      - /url: "#proposals"
  - region "Contributions":
    - heading "Contributions" [level=2]
    - text: Every eligible proposal can be funded
    - status: Wait for the original transaction or callback, or correct its binding. No automatic repurchase.
    - list:
      - listitem:
        - article:
          - heading "Update HTML page · site" [level=3]
          - text: Eligible
          - paragraph: Improve the introduction while keeping the cover and the original round marker.
          - group:
            - text: Proposal details
            - term: Proposal
            - definition:
              - code: fx-prop-2
              - button "Copy proposal ID": Copy
            - term: Anchor
            - definition:
              - code: fx-branch-1:3
              - button "Copy proposal anchor": Copy
            - term: Inputs
            - definition: site@3, cover@2
            - term: Proposer
            - definition:
              - code: "0x2c596e12dBB8A46D7700f586e5f793aD483a76b4"
              - button "Copy proposer": Copy
            - term: Publication
            - definition: Not requested
          - button "Review funding" [disabled]
      - listitem:
        - article:
          - heading "Update Markdown · notes" [level=3]
          - text: Funded
          - paragraph: Expand the notes with the project goal, how to fund work and how to fork.
          - group:
            - text: Proposal details
            - term: Proposal
            - definition:
              - code: fx-prop-1
              - button "Copy proposal ID": Copy
            - term: Anchor
            - definition:
              - code: fx-branch-1:3
              - button "Copy proposal anchor": Copy
            - term: Inputs
            - definition: notes@1
            - term: Proposer
            - definition:
              - code: "0x1ADFc9D29e5b902DdcaD6316C899b2b76bA3B3Da"
              - button "Copy proposer": Copy
            - term: Publication
            - definition: Not requested
      - listitem:
        - article:
          - heading "Create PNG image · banner" [level=3]
          - text: Stale anchor
          - paragraph: Create a banner image.
          - group:
            - text: Proposal details
            - term: Proposal
            - definition:
              - code: fx-prop-0
              - button "Copy proposal ID": Copy
            - term: Anchor
            - definition:
              - code: fx-branch-1:2
              - button "Copy proposal anchor": Copy
            - term: Inputs
            - definition: None
            - term: Proposer
            - definition:
              - code: "0x1ADFc9D29e5b902DdcaD6316C899b2b76bA3B3Da"
              - button "Copy proposer": Copy
            - term: Publication
            - definition: Not requested
          - button "Prepare at current checkpoint"
  - region "Funding and build status":
    - heading "Funding and build status" [level=2]
    - button "Refresh chain state"
    - list:
      - listitem:
        - heading "Attempt 1 · Not a completed round" [level=3]
        - list "Independent execution stages":
          - listitem:
            - text: Token approval
            - strong: Confirmed
          - listitem:
            - text: Purchase
            - strong: Confirmed
          - listitem:
            - text: Admission
            - strong: Confirmed
          - listitem:
            - text: Execution
            - strong: Pending
          - listitem:
            - text: Callback
            - strong: Pending
          - listitem:
            - text: Binding
            - strong: Not started
          - listitem:
            - text: File verification
            - strong: Not started
          - listitem:
            - text: Git
            - strong: Not started
          - listitem:
            - text: Publication
            - strong: Not started
        - paragraph: Callback pending. No timeout unlock, automatic refund or automatic retry
        - group:
          - text: Transaction and attempt identity
          - term: Proposal
          - definition: fx-prop-1
          - term: Sponsor
          - definition:
            - code: "0x2c596e12dBB8A46D7700f586e5f793aD483a76b4"
            - button "Copy sponsor": Copy
          - term: Original transaction
          - definition:
            - code: "0x6308b37379629797f7084bde8ef81d138ac34d311b7bebfa8470828f6065329a"
            - button "Copy original transaction hash": Copy
            - text: · nonce 2 · chain 31337
        - 'button "Demo: deliver callback"'
  - group:
    - text: Branch, network and execution identity
    - term: Chain
    - definition: Local demo chain · 31337
    - term: Branch / spender
    - definition:
      - code: "0xe881c7ad745f92c87dFECBD727479248edCB78F7"
      - button "Copy Branch": Copy
    - term: Latest checkpoint
    - definition:
      - code: fx-branch-1:3
      - button "Copy latest checkpoint": Copy
    - term: Selected checkpoint
    - definition:
      - code: fx-branch-1:3
      - button "Copy selected checkpoint": Copy
    - term: IMD project / latest execution
    - definition: fx-project-1 / fx-job-3
  - group:
    - text: Demo failure controls (next attempt only) Callback outcome
    - combobox "Callback outcome":
      - option "Accept and bind"
      - option "Missing; remain pending" [selected]
      - option "Refused; status 1"
      - option "Frozen; status 2"
      - option "Accepted; invalid binding"
    - text: Purchase receipt
    - combobox "Purchase receipt":
      - option "Confirmed" [selected]
      - option "Unknown; reconcile"
    - checkbox "Reject next simulated signature"
    - text: Reject next simulated signature
- contentinfo:
  - text: STEPS · Open Workshop
  - link "Stepstoke on X":
    - /url: https://x.com/stepstoke
  - text: Release candidate · No public deployment
```

# Test source

```ts
  4   | import { mkdir, writeFile } from "node:fs/promises";
  5   | 
  6   | // Regression cases for the reviewed revision findings. Fixture adapter only; no A1 or real wallet.
  7   | async function openDemo(page: Page, hash = "#/demo") {
  8   |   await page.goto(`./${hash}`);
  9   |   await page.evaluate(() => localStorage.clear());
  10  |   await page.goto(`./${hash}`);
  11  |   await page.reload();
  12  |   await expect(page.getByText("Demo mode").first()).toBeVisible();
  13  |   await demoSettings(page);
  14  |   if (hash.includes("/b/")) { await failureControls(page); await disclose(page, /^Complete asset table|^Branch, network|^Proposal details/); }
  15  | }
  16  | 
  17  | const fixtureState = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem("platform.fixture.v1") ?? "{}"));
  18  | const recovery = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem("w1.recovery.v1") ?? "[]"));
  19  | 
  20  | test("refused retry goes through a fresh fee/spender review and the new account's exact allowance; an unknown retry is journaled by its own hash/nonce", async ({ page }) => {
  21  |   await openDemo(page, "#/demo/b/fx-branch-1");
  22  |   await failureControls(page);
  23  |   await page.getByLabel("Callback outcome").selectOption("refused");
  24  |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  25  |   await row.getByRole("button", { name: "Review funding" }).click();
  26  |   await disclose(page, /^Exact proposal/);
  27  |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  28  |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  29  |   const refused = page.locator("#progress > ul > li").first();
  30  |   await expect(refused.locator(".stage", { hasText: "Callback" })).toContainText("Refused (status 1)");
  31  | 
  32  |   await identity(page, "Demo signing account", "1");
  33  |   await failureControls(page);
  34  |   await page.getByLabel("Callback outcome").selectOption("missing");
  35  |   await failureControls(page);
  36  |   await page.getByLabel("Purchase receipt").selectOption("unknown");
  37  |   const before = await fixtureState(page);
  38  |   await page.locator("#progress > ul > li").first().getByRole("button", { name: "Review identical paid retry" }).click();
  39  |   const panel = funding(page);
  40  |   await expect(panel).toBeVisible();
  41  |   await expect(panel).toContainText("refused attempt 1");
  42  |   await expect(panel).toContainText("Approval spender");
  43  |   await expect(panel).toContainText("Current price");
  44  |   await expect(panel).toContainText("job.continue");
  45  |   await expect(panel.getByRole("button", { name: "2. Purchase identical retry" })).toBeDisabled();
  46  |   // Opening the review signs nothing.
  47  |   const opened = await fixtureState(page);
  48  |   expect(opened.sponsorships).toHaveLength(before.sponsorships.length);
  49  |   expect(opened.nonces).toEqual(before.nonces);
  50  | 
  51  |   await panel.getByRole("button", { name: "1. Approve exact amount" }).click();
  52  |   await expect(panel.getByRole("button", { name: "1. Approval confirmed" })).toBeDisabled();
  53  |   const approved = await fixtureState(page);
  54  |   const bAddr = Object.keys(approved.nonces).find((k) => !(k in before.nonces))!;
  55  |   expect(Object.entries(approved.allowances).find(([k]) => k.startsWith(`${bAddr}:`))?.[1]).toBe("25000000000000000000");
  56  |   await panel.getByRole("button", { name: "2. Purchase identical retry" }).click();
  57  | 
  58  |   const retry = page.locator("#progress > ul > li").first();
  59  |   await expect(retry).toContainText("Attempt 2");
  60  |   await expect(retry.locator(".stage", { hasText: "Purchase" })).toContainText("Unknown; reconcile");
  61  |   await expect(retry.locator(".stage", { hasText: "Callback" })).toContainText("Not started");
  62  |   const after = await fixtureState(page);
  63  |   const sp = after.sponsorships.find((x: { attempt: number }) => x.attempt === 2);
  64  |   expect(sp.sponsor).toBe(bAddr);
  65  |   expect(after.nonces[bAddr]).toBe(2); // approval + purchase, both by B
  66  |   const branchAddr = after.branches.find((b: { id: string }) => b.id === "fx-branch-1").address;
  67  |   expect(after.allowances[`${bAddr}:${branchAddr}`]).toBe("0"); // exact amount consumed by B's own retry purchase
  68  |   const rec = await recovery(page);
  69  |   expect(rec.map((r: { sponsorshipId: string }) => r.sponsorshipId)).toContain(sp.id);
  70  |   const own = rec.find((r: { sponsorshipId: string }) => r.sponsorshipId === sp.id);
  71  |   expect(own.txHash).toBe(sp.txHash);
  72  |   expect(own.nonce).toBe(sp.nonce);
  73  |   expect(own.account).toBe(bAddr);
  74  | 
  75  |   // After a reload the retry reconciles by its own hash/nonce; nothing is purchased again.
  76  |   await page.reload();
  77  |   // Recovery hints belong to the account that signed: reconcile once B is the selected account again.
  78  |   await identity(page, "Demo signing account", "1");
  79  |   const shortHash = `${sp.txHash.slice(0, 6)}…${sp.txHash.slice(-4)}`;
  80  |   await expect(page.getByText(`Original transaction ${shortHash} / nonce ${sp.nonce}:`, { exact: false })).toBeVisible();
  81  |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  82  |   const settled = await fixtureState(page);
  83  |   expect(settled.sponsorships).toHaveLength(after.sponsorships.length);
  84  |   expect(settled.nonces[bAddr]).toBe(2);
  85  |   await page.screenshot({ type: "jpeg", quality: 45, scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-retry-review.jpg`, fullPage: false });
  86  | });
  87  | 
  88  | test("sponsorship progress shows the complete purchase hash and sponsor with copy controls", async ({ page }) => {
  89  |   await page.context().grantPermissions(["clipboard-read", "clipboard-write"]).catch(() => undefined);
  90  |   await openDemo(page, "#/demo/b/fx-branch-1");
  91  |   await page.getByLabel("Callback outcome").selectOption("missing");
  92  |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  93  |   await row.getByRole("button", { name: "Review funding" }).click();
  94  |   await disclose(page, /^Exact proposal/);
  95  |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  96  |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  97  |   const progress = page.locator("#progress > ul > li").first();
  98  |   await expect(progress.locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  99  |   const state = await fixtureState(page);
  100 |   const sp = state.sponsorships[0];
  101 |   await disclose(page, /^Transaction and attempt identity$/);
  102 |   await expect(progress.locator("code", { hasText: sp.txHash })).toHaveText(sp.txHash);
  103 |   await expect(progress.locator("code", { hasText: sp.sponsor })).toHaveText(sp.sponsor);
> 104 |   await expect(progress.getByRole("button", { name: "Copy transaction hash" })).toBeVisible();
      |                                                                                 ^ Error: expect(locator).toBeVisible() failed
  105 |   await expect(progress.getByRole("button", { name: "Copy sponsor" })).toBeVisible();
  106 |   await expect(progress).toContainText(`nonce ${sp.nonce} · chain 31337`);
  107 | });
  108 | 
  109 | test("switching a populated draft to image yields a create draft with no inputs", async ({ page }) => {
  110 |   await openDemo(page, "#/demo/b/fx-branch-1");
  111 |   const form = await prepare(page);
  112 |   await form.getByLabel("Type").selectOption({ label: "HTML page" });
  113 |   await form.getByLabel("site · HTML page · round 3").check();
  114 |   await form.getByLabel("New asset name").fill("cover-new");
  115 |   await form.getByLabel("Requirement").fill("A new cover");
  116 |   await form.getByLabel("Type").selectOption({ label: "PNG image" });
  117 |   await expect(form.getByLabel("site · HTML page · round 3")).not.toBeChecked();
  118 |   await expect(form.getByLabel("New asset name")).toHaveValue("cover-new");
  119 |   await form.getByRole("button", { name: "Review proposal" }).click();
  120 |   await expect(form.getByRole("button", { name: "Sign and submit proposal" })).toBeVisible();
  121 |   await expect(form.getByLabel("Review proposal")).toContainText("Create PNG image · Asset slot cover-new");
  122 | 
  123 |   // An update draft switched to image returns to create and drops the forced target input.
  124 |   await form.getByRole("button", { name: "Back to edit" }).click();
  125 |   await form.getByLabel("Type").selectOption({ label: "HTML page" });
  126 |   await form.getByLabel("Update").check();
  127 |   await form.getByLabel("Target asset").selectOption("site");
  128 |   await expect(form.getByLabel(/site · HTML page · round 3/)).toBeChecked();
  129 |   await form.getByLabel("Type").selectOption({ label: "PNG image" });
  130 |   await expect(form.getByLabel("Create")).toBeChecked();
  131 |   await expect(form.getByLabel("Update")).not.toBeChecked();
  132 |   await expect(form.getByLabel("New asset name")).toHaveValue("");
  133 |   await expect(form.getByLabel(/site · HTML page · round 3/)).not.toBeChecked();
  134 |   await form.getByLabel("New asset name").fill("banner2");
  135 |   await form.getByRole("button", { name: "Review proposal" }).click();
  136 |   await expect(form.getByRole("button", { name: "Sign and submit proposal" })).toBeVisible();
  137 | });
  138 | 
  139 | test("a verified single output updates the file stage; a wide Markdown table stays readable in its own scroll region", async ({ page }) => {
  140 |   await openDemo(page, "#/demo");
  141 |   await page.getByRole("button", { name: "Create project" }).click();
  142 |   await page.getByLabel("Project title").fill("Single file verification");
  143 |   await page.getByLabel(/Fixed goal/).fill("Verify file stage and wide tables");
  144 |   await page.getByRole("button", { name: "Review creation" }).click();
  145 |   await page.getByRole("button", { name: "Sign and create" }).click();
  146 |   await page.getByRole("link", { name: "Open project" }).click();
  147 |   await expect(page.getByRole("heading", { name: "Single file verification" })).toBeVisible();
  148 |   const form = await prepare(page);
  149 |   await form.getByLabel("New asset name").fill("wide-table");
  150 |   const cells = (c: string) => `| ${Array(20).fill(c).join(" | ")} |`;
  151 |   await form.getByLabel("Requirement").fill(`${cells("A")}\n${cells("---")}\n${cells("B")}`);
  152 |   await form.getByRole("button", { name: "Review proposal" }).click();
  153 |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  154 |   await failureControls(page);
  155 |   await page.getByLabel("Callback outcome").selectOption("accepted");
  156 |   const row = page.locator("#proposals li", { hasText: "Create Markdown · wide-table" });
  157 |   await row.getByRole("button", { name: "Review funding" }).click();
  158 |   await disclose(page, /^Exact proposal/);
  159 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  160 |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  161 |   const progress = page.locator("#progress > ul > li").first();
  162 |   await expect(progress.locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  163 |   await expect(progress.locator(".stage", { hasText: "File verification" })).toContainText("Pending");
  164 | 
  165 |   const asset = page.locator("#assets");
  166 |   await selectRound(page, 1);
  167 |   await selectFile(page, "wide-table");
  168 |   await expect(asset.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  169 |   await expect(progress.locator(".stage", { hasText: "File verification" })).toContainText("Verified locally");
  170 |   await expect(progress).toContainText("local observation");
  171 | 
  172 |   const region = asset.getByRole("region", { name: "Document table (scroll horizontally)" });
  173 |   await expect(region).toBeVisible();
  174 |   const m = await region.evaluate((el) => {
  175 |     const ths = Array.from(el.querySelectorAll("th"));
  176 |     const glyph = (cell: Element) => { const r = document.createRange(); r.selectNodeContents(cell); return r.getBoundingClientRect(); };
  177 |     const rects = ths.map(glyph);
  178 |     let overlap = 0;
  179 |     for (let i = 1; i < rects.length; i++) overlap = Math.max(overlap, rects[i - 1].right - rects[i].left);
  180 |     const preview = el.closest(".preview")!;
  181 |     const panel = el.closest("#assets")!;
  182 |     const download = preview.querySelector<HTMLAnchorElement>("a[download]")!;
  183 |     const box = (node: Element) => {
  184 |       const { left, right, width } = node.getBoundingClientRect();
  185 |       return { left, right, width };
  186 |     };
  187 |     return { minCell: Math.min(...ths.map((t) => t.getBoundingClientRect().width)), glyph: rects[0].width, overlap,
  188 |       region: box(el), preview: box(preview), panel: box(panel), download: box(download),
  189 |       children: Array.from(preview.children).map(box), clientWidth: el.clientWidth, scrollWidth: el.scrollWidth,
  190 |       hostOverflow: document.documentElement.scrollWidth - innerWidth, vw: innerWidth };
  191 |   });
  192 |   expect(m.minCell).toBeGreaterThan(m.glyph);
  193 |   expect(m.overlap).toBeLessThanOrEqual(0);
  194 |   expect(m.hostOverflow).toBe(0);
  195 |   expect(m.clientWidth).toBeLessThan(m.scrollWidth);
  196 |   for (const child of [m.preview, m.region, m.download, ...m.children]) {
  197 |     expect(child.left).toBeGreaterThanOrEqual(m.panel.left);
  198 |     expect(child.right).toBeLessThanOrEqual(m.panel.right);
  199 |     expect(child.right).toBeLessThanOrEqual(m.vw);
  200 |   }
  201 |   await region.focus();
  202 |   await expect(region).toBeFocused();
  203 |   await page.keyboard.press("ArrowRight");
  204 |   await expect.poll(() => region.evaluate((el) => el.scrollLeft)).toBeGreaterThan(0);
```