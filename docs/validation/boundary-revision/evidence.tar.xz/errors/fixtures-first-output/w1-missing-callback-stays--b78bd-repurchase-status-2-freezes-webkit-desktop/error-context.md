# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: w1.spec.ts >> missing callback stays pending; refused retry; bad binding resubmits without repurchase; status 2 freezes
- Location: tests/e2e/w1.spec.ts:131:1

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.fill: Test timeout of 45000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Prepare a contribution' }).getByLabel('New asset name')

```

# Page snapshot

```yaml
- generic [ref=f4e2]:
  - link "Skip to main content" [ref=f4e3]:
    - /url: "#main"
  - banner [ref=f4e4]:
    - link "STEPS" [ref=f4e5]:
      - /url: "#/"
    - navigation "Platform" [ref=f4e7]:
      - link "Projects" [ref=f4e8]:
        - /url: "#/"
      - link "Demo" [ref=f4e9]:
        - /url: "#/demo"
      - link "Components" [ref=f4e10]:
        - /url: "#/showcase"
    - button "Connect wallet" [ref=f4e12] [cursor=pointer]
  - generic [ref=f4e13]:
    - generic [ref=f4e14]: Demo mode
    - generic [ref=f4e15]: Deterministic local fixtures. Simulated signatures only.
    - group [ref=f4e16]:
      - generic "Demo settings" [ref=f4e17] [cursor=pointer]
      - option "Demo account A" [selected]
      - option "Demo account B"
  - main [ref=f4e18]:
    - generic [ref=f4e19]:
      - region [ref=f4e20]:
        - link "← All projects" [ref=f4e21]:
          - /url: "#/demo"
        - heading "Relay introduction" [level=1] [ref=f4e23]
        - paragraph [ref=f4e24]: Build a public introduction to the relay, with a cover image and project notes.
      - region [ref=f4e25]:
        - generic [ref=f4e26]:
          - heading "Sequence" [level=2] [ref=f4e27]
          - generic [ref=f4e28]: 5 accepted checkpoints in chain order
        - list [ref=f4e29]:
          - listitem [ref=f4e30]:
            - button "Select Project created" [ref=f4e31] [cursor=pointer]:
              - generic [ref=f4e32]: "00"
              - generic [ref=f4e33]:
                - strong [ref=f4e34]: Project created
                - generic [ref=f4e35]: Fixed goal; no paid round
          - listitem [ref=f4e36]:
            - button "Select Round 1" [ref=f4e37] [cursor=pointer]:
              - generic [ref=f4e38]: "01"
              - generic [ref=f4e39]:
                - strong [ref=f4e40]: Round 1
                - generic [ref=f4e41]: HTML page + Markdown
          - listitem [ref=f4e42]:
            - button "Select Round 2" [ref=f4e43] [cursor=pointer]:
              - generic "Verified local thumbnail" [ref=f4e44]:
                - img "Verified PNG thumbnail" [ref=f4e45]
              - generic [ref=f4e46]: "02"
              - generic [ref=f4e47]:
                - strong [ref=f4e48]: Round 2
                - generic [ref=f4e49]: PNG image
          - listitem [ref=f4e50]:
            - button "Select Round 3" [ref=f4e51] [cursor=pointer]:
              - generic [ref=f4e52]: "03"
              - generic [ref=f4e53]:
                - strong [ref=f4e54]: Round 3
                - generic [ref=f4e55]: HTML page
          - listitem [ref=f4e56]:
            - button "Select Round 4, Latest, Selected" [ref=f4e57] [cursor=pointer]:
              - generic [ref=f4e58]: "04"
              - generic [ref=f4e59]:
                - strong [ref=f4e60]: Round 4
                - generic [ref=f4e61]: Markdown
              - generic [ref=f4e62]:
                - generic [ref=f4e63]: Latest
                - generic [ref=f4e64]: Selected
      - region [ref=f4e65]:
        - generic [ref=f4e66]:
          - generic [ref=f4e67]:
            - heading "Round 4 output" [level=2] [ref=f4e68]
            - paragraph [ref=f4e69]: Selected checkpoint · Accepted execution
          - button "Historical Fork" [ref=f4e70] [cursor=pointer]
        - group "Files in selected snapshot" [ref=f4e71]:
          - button "assets/cover.png PNG image" [ref=f4e72] [cursor=pointer]:
            - text: assets/cover.png
            - generic [ref=f4e73]: PNG image
          - button "assets/notes.md Markdown" [pressed] [ref=f4e74] [cursor=pointer]:
            - text: assets/notes.md
            - generic [ref=f4e75]: Markdown
          - button "assets/site.html HTML page" [ref=f4e76] [cursor=pointer]:
            - text: assets/site.html
            - generic [ref=f4e77]: HTML page
        - generic [ref=f4e78]:
          - generic [ref=f4e79]:
            - generic [ref=f4e80]: Verified locally · SHA-256, length, media
            - link "Download verified file" [ref=f4e81]:
              - /url: blob:http://127.0.0.1:4175/0ccb8987-0390-4280-b7fa-a4f28d761e94
          - generic [ref=f4e82]:
            - heading "notes" [level=1] [ref=f4e83]
            - paragraph [ref=f4e84]: Expand the notes with the project goal, how to fund work and how to fork.
            - paragraph [ref=f4e85]: "Inputs: notes@R1"
          - group [ref=f4e86]:
            - generic "File verification details" [ref=f4e87] [cursor=pointer]
        - paragraph [ref=f4e88]: "File origin: fx-branch-1 · checkpoint fx-branch-1:4 · producer job fx-job-fx-branch-1-4. Changed in this checkpoint."
        - group [ref=f4e89]:
          - generic "Complete asset table (3) and checkpoint evidence" [ref=f4e90] [cursor=pointer]
      - region [ref=f4e91]:
        - generic [ref=f4e92]:
          - heading "What comes next?" [level=2] [ref=f4e93]
          - paragraph [ref=f4e94]: Prepare work at the current checkpoint, or fund an eligible contribution.
          - paragraph [ref=f4e95]: Continue opens preparation only. Proposal, approval and payment stay separate.
        - generic [ref=f4e96]:
          - button "Continue" [active] [ref=f4e97] [cursor=pointer]
          - link "View contributions (0)" [ref=f4e98]:
            - /url: "#proposals"
      - region [ref=f4e99]:
        - generic [ref=f4e100]:
          - heading "Contributions" [level=2] [ref=f4e101]
          - generic [ref=f4e102]: Every eligible proposal can be funded
        - list [ref=f4e103]:
          - listitem [ref=f4e104]:
            - article [ref=f4e105]:
              - generic [ref=f4e106]:
                - heading "Update Markdown · notes" [level=3] [ref=f4e107]:
                  - text: Update Markdown
                  - generic [ref=f4e108]: · notes
                - generic [ref=f4e109]: Funded
              - paragraph [ref=f4e110]: Expand the notes with the project goal, how to fund work and how to fork.
              - group [ref=f4e111]:
                - generic "Proposal details" [ref=f4e112] [cursor=pointer]
          - listitem [ref=f4e113]:
            - article [ref=f4e114]:
              - generic [ref=f4e115]:
                - heading "Update HTML page · site" [level=3] [ref=f4e116]:
                  - text: Update HTML page
                  - generic [ref=f4e117]: · site
                - generic [ref=f4e118]: Stale anchor
              - paragraph [ref=f4e119]: Improve the introduction while keeping the cover and the original round marker.
              - group [ref=f4e120]:
                - generic "Proposal details" [ref=f4e121] [cursor=pointer]
              - button "Prepare at current checkpoint" [ref=f4e122] [cursor=pointer]
          - listitem [ref=f4e123]:
            - article [ref=f4e124]:
              - generic [ref=f4e125]:
                - heading "Create PNG image · banner" [level=3] [ref=f4e126]:
                  - text: Create PNG image
                  - generic [ref=f4e127]: · banner
                - generic [ref=f4e128]: Stale anchor
              - paragraph [ref=f4e129]: Create a banner image.
              - group [ref=f4e130]:
                - generic "Proposal details" [ref=f4e131] [cursor=pointer]
              - button "Prepare at current checkpoint" [ref=f4e132] [cursor=pointer]
      - region [ref=f4e133]:
        - generic [ref=f4e134]:
          - heading "Funding and build status" [level=2] [ref=f4e135]
          - button "Refresh chain state" [ref=f4e136] [cursor=pointer]
        - status [ref=f4e137]: "Original transaction 0x6308…329a / nonce 2: purchase Confirmed, callback Pending."
        - list [ref=f4e138]:
          - listitem [ref=f4e139]:
            - heading "Attempt 1 · Bound to checkpoint" [level=3] [ref=f4e140]:
              - text: Attempt 1
              - generic [ref=f4e141]: · Bound to checkpoint
            - list "Independent execution stages" [ref=f4e142]:
              - listitem [ref=f4e143]:
                - generic [ref=f4e144]: Token approval
                - strong [ref=f4e145]: Confirmed
              - listitem [ref=f4e146]:
                - generic [ref=f4e147]: Purchase
                - strong [ref=f4e148]: Confirmed
              - listitem [ref=f4e149]:
                - generic [ref=f4e150]: Admission
                - strong [ref=f4e151]: Confirmed
              - listitem [ref=f4e152]:
                - generic [ref=f4e153]: Execution
                - strong [ref=f4e154]: Confirmed
              - listitem [ref=f4e155]:
                - generic [ref=f4e156]: Callback
                - strong [ref=f4e157]: Confirmed
              - listitem [ref=f4e158]:
                - generic [ref=f4e159]: Binding
                - strong [ref=f4e160]: Confirmed
              - listitem [ref=f4e161]:
                - generic [ref=f4e162]: File verification
                - strong [ref=f4e163]: Verified locally
              - listitem [ref=f4e164]:
                - generic [ref=f4e165]: Git
                - strong [ref=f4e166]: Pending
              - listitem [ref=f4e167]:
                - generic [ref=f4e168]: Publication
                - strong [ref=f4e169]: Not applicable
            - paragraph [ref=f4e170]: Checkpoint bound. File verification updates after the actual output bytes are verified locally
            - paragraph [ref=f4e171]: SHA-256, length and media checked in this page. This is a local observation; reload requires verification again.
            - group [ref=f4e172]:
              - generic "Transaction and attempt identity" [ref=f4e173] [cursor=pointer]
      - group [ref=f4e174]:
        - generic "Branch, network and execution identity" [ref=f4e175] [cursor=pointer]
      - group [ref=f4e176]:
        - generic "Demo failure controls (next attempt only)" [ref=f4e177] [cursor=pointer]
        - option "Accept and bind" [selected]
        - option "Missing; remain pending"
        - option "Refused; status 1"
        - option "Frozen; status 2"
        - option "Accepted; invalid binding"
        - option "Confirmed" [selected]
        - option "Unknown; reconcile"
  - contentinfo [ref=f4e178]:
    - generic [ref=f4e179]: STEPS · Open Workshop
    - link "Stepstoke on X" [ref=f4e180]:
      - /url: https://x.com/stepstoke
    - generic [ref=f4e181]: Release candidate · No public deployment
```

# Test source

```ts
  54  | test("propose, sponsor with exact allowance (account B), callback, binding, retained assets", async ({ page }) => {
  55  |   await openDemo(page, "#/demo/b/fx-branch-1");
  56  |   await identity(page, "Demo signing account", "1");
  57  |   // History shows HTML R1 -> image R2 -> HTML R3 provenance.
  58  |   await expect(page.locator("#assets").getByRole("rowheader", { name: /site@3/ })).toBeVisible();
  59  |   // Propose a document create; update target is mandatory input on updates.
  60  |   const form = await prepare(page);
  61  |   await form.getByLabel("New asset name").fill("faq");
  62  |   await form.getByLabel("Requirement").fill("Write frequently asked questions.");
  63  |   await form.getByRole("button", { name: "Review proposal" }).click();
  64  |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  65  |   await expect(page.getByRole("dialog", { name: "Prepare a contribution" })).toHaveCount(0);
  66  |   // Existing current proposals stay current.
  67  |   await expect(page.locator("#proposals .tag-accent", { hasText: "Eligible" })).toHaveCount(3);
  68  | 
  69  |   await failureControls(page);
  70  |   await page.getByLabel("Callback outcome").selectOption("accepted");
  71  |   const row = page.locator("#proposals li", { hasText: "Update HTML page · site" });
  72  |   await row.getByRole("button", { name: "Review funding" }).click();
  73  |   await disclose(page, /^Exact proposal/);
  74  |   await expect(funding(page).getByText("job.continue / fx-job-3")).toBeVisible();
  75  |   await expect(funding(page).getByText("Sponsors cannot edit proposals", { exact: false })).toBeVisible();
  76  |   await expect(funding(page).getByRole("button", { name: "2. Purchase execution" })).toBeDisabled();
  77  |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  78  |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).dblclick();
  79  |   const sp = page.locator("#progress > ul > li").first();
  80  |   await expect(sp.getByText("Binding confirmed")).toHaveCount(0);
  81  |   await expect(sp.locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  82  |   await expect(sp.locator(".stage", { hasText: "Git" })).toContainText("Pending");
  83  |   await expect(page.locator("#progress > ul > li")).toHaveCount(1);
  84  |   // New checkpoint R4 keeps untouched notes R1 and cover R2.
  85  |   await selectRound(page, 4);
  86  |   await expect(page.getByRole("heading", { name: "Round 4 output" })).toBeVisible();
  87  |   await expect(page.locator("#assets")).toContainText("cover@2");
  88  |   await selectFile(page, "site");
  89  |   await expect(page.locator("#assets")).toContainText("notes@1");
  90  |   // Other proposals bound to R3 are now stale and cannot be sponsored.
  91  |   await expect(page.locator("#proposals li", { hasText: "Update Markdown · notes" })).toContainText("Prepare at current checkpoint");
  92  |   // Verify the produced HTML: sha/length/format, sandboxed preview.
  93  |   await selectFile(page, "site");
  94  |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  95  |   await expect(page.locator("iframe.frame")).toHaveAttribute("sandbox", "");
  96  |   const download = page.waitForEvent("download");
  97  |   await page.getByRole("link", { name: "Download verified file" }).click();
  98  |   expect((await download).suggestedFilename()).toBe("site.html");
  99  | });
  100 | 
  101 | test("stale proposal resubmission, sign rejection, account and network change", async ({ page }) => {
  102 |   await openDemo(page, "#/demo/b/fx-branch-1");
  103 |   const stale = page.locator("#proposals li", { hasText: "Create PNG image · banner" });
  104 |   await expect(stale).toContainText("Stale anchor");
  105 |   await expect(stale.getByRole("button", { name: "Review funding" })).toHaveCount(0);
  106 |   await stale.getByRole("button", { name: "Prepare at current checkpoint" }).click();
  107 |   await expect(page.getByRole("heading", { name: "Resubmit proposal" })).toBeVisible();
  108 |   await page.keyboard.press("Escape");
  109 | 
  110 |   // Rejection returns to idle with a message; nothing is recorded.
  111 |   await identity(page, "Reject next simulated signature", true);
  112 |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  113 |   await row.getByRole("button", { name: "Review funding" }).click();
  114 |   await disclose(page, /^Exact proposal/);
  115 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  116 |   await expect(funding(page).getByText("Signature rejected in the wallet")).toBeVisible();
  117 |   await expect(page.getByLabel("Reject next simulated signature")).not.toBeChecked();
  118 |   await expect(funding(page).getByRole("button", { name: "1. Approve exact amount" })).toBeEnabled();
  119 | 
  120 |   // Switching account discards the prepared action.
  121 |   await identity(page, "Demo signing account", "1");
  122 |   await expect(page.getByText("Account or network changed. Preparation cancelled; review again before signing.")).toBeVisible();
  123 |   await expect(funding(page)).toHaveCount(0);
  124 | 
  125 |   // Wrong network disables actions.
  126 |   await identity(page, "Simulate wrong network", true);
  127 |   await expect(row.getByRole("button", { name: "Review funding" })).toBeDisabled();
  128 |   await expect(page.getByText(/select Local demo chain/)).toBeVisible();
  129 | });
  130 | 
  131 | test("missing callback stays pending; refused retry; bad binding resubmits without repurchase; status 2 freezes", async ({ page }) => {
  132 |   await openDemo(page, "#/demo/b/fx-branch-1");
  133 |   const sponsor = async (title: string) => {
  134 |     const row = page.locator("#proposals li", { hasText: title });
  135 |     await row.getByRole("button", { name: "Review funding" }).click();
  136 |   await disclose(page, /^Exact proposal/);
  137 |     await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  138 |     await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  139 |   };
  140 |   await failureControls(page);
  141 |   await page.getByLabel("Callback outcome").selectOption("missing");
  142 |   await sponsor("Update Markdown · notes");
  143 |   const first = page.locator("#progress > ul > li").first();
  144 |   await expect(first.locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  145 |   await page.reload();
  146 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  147 |   await page.locator("#progress > ul > li").first().getByRole("button", { name: "Demo: deliver callback" }).click();
  148 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  149 |   await selectRound(page, 4);
  150 |   await expect(page.getByRole("heading", { name: "Round 4 output" })).toBeVisible();
  151 | 
  152 |   // New proposal on R4, refused (status 1), explicit identical retry.
  153 |   const form = await prepare(page);
> 154 |   await form.getByLabel("New asset name").fill("faq");
      |                                           ^ Error: locator.fill: Test timeout of 45000ms exceeded.
  155 |   await form.getByLabel("Requirement").fill("Frequently asked questions");
  156 |   await form.getByRole("button", { name: "Review proposal" }).click();
  157 |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  158 |   await failureControls(page);
  159 |   await page.getByLabel("Callback outcome").selectOption("refused");
  160 |   await sponsor("Create Markdown · faq");
  161 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Callback" })).toContainText("Refused (status 1)");
  162 |   await failureControls(page);
  163 |   await page.getByLabel("Callback outcome").selectOption("bad_binding");
  164 |   const refused = page.locator("#progress > ul > li").first();
  165 |   await refused.getByRole("button", { name: "Review identical paid retry" }).click();
  166 |   await expect(funding(page).getByRole("heading", { name: "Review identical paid retry" })).toBeVisible();
  167 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  168 |   await funding(page).getByRole("button", { name: "2. Purchase identical retry" }).click();
  169 |   const retry = page.locator("#progress > ul > li").first();
  170 |   await expect(retry).toContainText("Attempt 2");
  171 |   await expect(retry.locator(".stage", { hasText: "Binding" })).toContainText("Failed");
  172 |   await retry.getByRole("button", { name: "Correct binding without purchase" }).click();
  173 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  174 |   await expect(page.locator("#progress > ul > li")).toHaveCount(3);
  175 |   await selectRound(page, 5);
  176 |   await expect(page.getByRole("heading", { name: "Round 5 output" })).toBeVisible();
  177 | 
  178 |   // Status 2 freezes purchases on this branch.
  179 |   await prepare(page);
  180 |   await form.getByLabel("New asset name").fill("faq2");
  181 |   await form.getByLabel("Requirement").fill("Write another note");
  182 |   await form.getByRole("button", { name: "Review proposal" }).click();
  183 |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  184 |   await failureControls(page);
  185 |   await page.getByLabel("Callback outcome").selectOption("failed");
  186 |   await sponsor("Create Markdown · faq2");
  187 |   await expect(page.getByText("Purchases frozen", {exact:false})).toBeVisible();
  188 | });
  189 | 
  190 | test("unknown purchase reconciles by original hash/nonce after reload, never repurchases", async ({ page }) => {
  191 |   await openDemo(page, "#/demo/b/fx-branch-1");
  192 |   await failureControls(page);
  193 |   await page.getByLabel("Purchase receipt").selectOption("unknown");
  194 |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  195 |   await row.getByRole("button", { name: "Review funding" }).click();
  196 |   await disclose(page, /^Exact proposal/);
  197 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  198 |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  199 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Purchase" })).toContainText("Unknown; reconcile");
  200 |   await page.reload();
  201 |   await expect(page.getByText(/Original transaction.*purchase Confirmed/)).toBeVisible();
  202 |   await expect(page.locator("#progress > ul > li")).toHaveCount(1);
  203 | });
  204 | 
  205 | test("fork an accepted historical checkpoint copies that asset set only", async ({ page }) => {
  206 |   await openDemo(page, "#/demo/b/fx-branch-1");
  207 |   await selectRound(page, 2);
  208 |   const r2 = page.getByRole("dialog", { name: "Historical Fork" });
  209 |   await page.getByRole("button", { name: "Historical Fork", exact: true }).click();
  210 |   await r2.getByLabel("Fork direction (fixed after creation)").fill("Develop an English introduction");
  211 |   await r2.getByRole("button", { name: "Review fork" }).click();
  212 |   await expect(r2.getByText("notes@1, site@1, cover@2")).toBeVisible();
  213 |   await r2.getByRole("button", { name: "Sign and fork" }).click();
  214 |   await r2.getByRole("link", { name: "Open fork" }).click();
  215 |   await expect(page.getByText("Fork direction", { exact: false }).first()).toBeVisible();
  216 |   await disclose(page, /^Branch, network/);
  217 |   await expect(page.getByText("None / None")).toBeVisible();
  218 |   await selectFile(page, "site");
  219 |   await expect(page.locator("#assets")).toContainText("site@1");
  220 |   await expect(page.locator("#assets")).toContainText("File origin: fx-branch-1");
  221 |   await expect(page.getByText("No proposals yet", { exact: false })).toBeVisible();
  222 |   // Copied historical bytes still verify against their original producer job.
  223 |   await selectFile(page, "cover");
  224 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  225 |   await expect(page.getByRole("img", { name: "cover from round 2" })).toBeVisible();
  226 | });
  227 | 
  228 | test("workspace layout at this project's width has no horizontal scroll", async ({ page }) => {
  229 |   await openDemo(page, "#/demo/b/fx-branch-1");
  230 |   await expect(page.getByRole("heading", { name: "Relay introduction" })).toBeVisible();
  231 |   await page.getByText("Demo settings", {exact:true}).click();
  232 |   await page.evaluate(() => scrollTo(0, 0));
  233 |   await expect(page.getByRole("button", { name: /^Select Round 3,/ })).toBeInViewport({ ratio: 1 });
  234 |   await expect(page.getByText("Demo mode").first()).toBeInViewport();
  235 |   await page.screenshot({ type: "jpeg", quality: 45, scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace-first.jpg` });
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(0);
  237 |   await selectFile(page, "site");
  238 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  239 |   await page.screenshot({ scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace.jpg`, type: "jpeg", quality: 55, fullPage: false });
  240 | });
  241 | 
  242 | test("malicious files stay isolated and broken files never get a verified badge", async ({ page }) => {
  243 |   await openDemo(page, "#/demo/b/fx-branch-sec");
  244 |   const open = (key: string) => selectFile(page, key);
  245 | 
  246 |   await open("evil-site");
  247 |   const frame = page.locator("iframe.frame");
  248 |   await expect(frame).toHaveAttribute("sandbox", "");
  249 |   await expect(page.frameLocator("iframe.frame").locator("#evil")).toHaveText("Hostile HTML fixture");
  250 |   await page.waitForTimeout(500);
  251 |   expect(await page.evaluate(() => localStorage.getItem("w1.pwned"))).toBeNull();
  252 |   expect(page.url()).toContain("#/demo/b/fx-branch-sec");
  253 |   expect(await page.title()).not.toBe("SCRIPT_RAN");
  254 |   expect(page.context().pages()).toHaveLength(1);
```