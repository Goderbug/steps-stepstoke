# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: w1.spec.ts >> missing callback stays pending; refused retry; bad binding resubmits without repurchase; status 2 freezes
- Location: tests/e2e/w1.spec.ts:131:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#progress > ul > li').first().locator('.stage').filter({ hasText: 'Binding' })
Expected substring: "Confirmed"
Received string:    "BindingNot started"
Timeout: 15000ms

Call log:
  - Expect "toContainText" locator('#progress > ul > li').first().locator('.stage').filter({ hasText: 'Binding' }) with timeout 15000ms
  - waiting for locator('#progress > ul > li').first().locator('.stage').filter({ hasText: 'Binding' })
    34 × locator resolved to <li class="stage st-not_started">…</li>
       - unexpected value "BindingNot started"

```

```yaml
- listitem:
  - text: Binding
  - strong: Not started
```

# Test source

```ts
  48  |   await page.getByRole("link", { name: "Open project" }).click();
  49  |   await expect(page.getByText("The first output starts here")).toBeVisible();
  50  |   await disclose(page, /^Branch, network/);
  51  |   await expect(page.getByText("None / None")).toBeVisible();
  52  | });
  53  | 
  54  | test("propose, sponsor with exact allowance (account B), callback, binding, retained assets", async ({ page }) => {
  55  |   await openDemo(page, "#/demo/b/fx-branch-1");
  56  |   await identity(page, "Demo signing account", "1");
  57  |   // History shows HTML R1 -> image R2 -> HTML R3 provenance.
  58  |   await expect(page.locator("#assets").getByRole("rowheader", { name: /site@3/ })).toBeVisible();
  59  |   // Propose a document create; update target is mandatory input on updates.
  60  |   const form = await prepare(page);
  61  |   await form.getByLabel("New asset name").fill("faq");
  62  |   await form.getByLabel("Requirement").fill("Write frequently asked questions.");
  63  |   await form.getByRole("button", { name: "Review proposal" }).click();
  64  |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  65  |   await expect(page.getByRole("dialog", { name: "Prepare a contribution" })).toHaveCount(0);
  66  |   // Existing current proposals stay current.
  67  |   await expect(page.locator("#proposals .tag-accent", { hasText: "Eligible" })).toHaveCount(3);
  68  | 
  69  |   await failureControls(page);
  70  |   await page.getByLabel("Callback outcome").selectOption("accepted");
  71  |   const row = page.locator("#proposals li", { hasText: "Update HTML page · site" });
  72  |   await row.getByRole("button", { name: "Review funding" }).click();
  73  |   await disclose(page, /^Exact proposal/);
  74  |   await expect(funding(page).getByText("job.continue / fx-job-3")).toBeVisible();
  75  |   await expect(funding(page).getByText("Sponsors cannot edit proposals", { exact: false })).toBeVisible();
  76  |   await expect(funding(page).getByRole("button", { name: "2. Purchase execution" })).toBeDisabled();
  77  |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  78  |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).dblclick();
  79  |   const sp = page.locator("#progress > ul > li").first();
  80  |   await expect(sp.getByText("Binding confirmed")).toHaveCount(0);
  81  |   await expect(sp.locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  82  |   await expect(sp.locator(".stage", { hasText: "Git" })).toContainText("Pending");
  83  |   await expect(page.locator("#progress > ul > li")).toHaveCount(1);
  84  |   // New checkpoint R4 keeps untouched notes R1 and cover R2.
  85  |   await selectRound(page, 4);
  86  |   await expect(page.getByRole("heading", { name: "Round 4 output" })).toBeVisible();
  87  |   await expect(page.locator("#assets")).toContainText("cover@2");
  88  |   await selectFile(page, "site");
  89  |   await expect(page.locator("#assets")).toContainText("notes@1");
  90  |   // Other proposals bound to R3 are now stale and cannot be sponsored.
  91  |   await expect(page.locator("#proposals li", { hasText: "Update Markdown · notes" })).toContainText("Prepare at current checkpoint");
  92  |   // Verify the produced HTML: sha/length/format, sandboxed preview.
  93  |   await selectFile(page, "site");
  94  |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  95  |   await expect(page.locator("iframe.frame")).toHaveAttribute("sandbox", "");
  96  |   const download = page.waitForEvent("download");
  97  |   await page.getByRole("link", { name: "Download verified file" }).click();
  98  |   expect((await download).suggestedFilename()).toBe("site.html");
  99  | });
  100 | 
  101 | test("stale proposal resubmission, sign rejection, account and network change", async ({ page }) => {
  102 |   await openDemo(page, "#/demo/b/fx-branch-1");
  103 |   const stale = page.locator("#proposals li", { hasText: "Create PNG image · banner" });
  104 |   await expect(stale).toContainText("Stale anchor");
  105 |   await expect(stale.getByRole("button", { name: "Review funding" })).toHaveCount(0);
  106 |   await stale.getByRole("button", { name: "Prepare at current checkpoint" }).click();
  107 |   await expect(page.getByRole("heading", { name: "Resubmit proposal" })).toBeVisible();
  108 |   await page.keyboard.press("Escape");
  109 | 
  110 |   // Rejection returns to idle with a message; nothing is recorded.
  111 |   await identity(page, "Reject next simulated signature", true);
  112 |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  113 |   await row.getByRole("button", { name: "Review funding" }).click();
  114 |   await disclose(page, /^Exact proposal/);
  115 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  116 |   await expect(funding(page).getByText("Signature rejected in the wallet")).toBeVisible();
  117 |   await expect(page.getByLabel("Reject next simulated signature")).not.toBeChecked();
  118 |   await expect(funding(page).getByRole("button", { name: "1. Approve exact amount" })).toBeEnabled();
  119 | 
  120 |   // Switching account discards the prepared action.
  121 |   await identity(page, "Demo signing account", "1");
  122 |   await expect(page.getByText("Account or network changed. Preparation cancelled; review again before signing.")).toBeVisible();
  123 |   await expect(funding(page)).toHaveCount(0);
  124 | 
  125 |   // Wrong network disables actions.
  126 |   await identity(page, "Simulate wrong network", true);
  127 |   await expect(row.getByRole("button", { name: "Review funding" })).toBeDisabled();
  128 |   await expect(page.getByText(/select Local demo chain/)).toBeVisible();
  129 | });
  130 | 
  131 | test("missing callback stays pending; refused retry; bad binding resubmits without repurchase; status 2 freezes", async ({ page }) => {
  132 |   await openDemo(page, "#/demo/b/fx-branch-1");
  133 |   const sponsor = async (title: string) => {
  134 |     const row = page.locator("#proposals li", { hasText: title });
  135 |     await row.getByRole("button", { name: "Review funding" }).click();
  136 |   await disclose(page, /^Exact proposal/);
  137 |     await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  138 |     await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  139 |   };
  140 |   await failureControls(page);
  141 |   await page.getByLabel("Callback outcome").selectOption("missing");
  142 |   await sponsor("Update Markdown · notes");
  143 |   const first = page.locator("#progress > ul > li").first();
  144 |   await expect(first.locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  145 |   await page.reload();
  146 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Callback" })).toContainText("Pending");
  147 |   await page.locator("#progress > ul > li").first().getByRole("button", { name: "Demo: deliver callback" }).click();
> 148 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
      |                                                                                                       ^ Error: expect(locator).toContainText(expected) failed
  149 |   await selectRound(page, 4);
  150 |   await expect(page.getByRole("heading", { name: "Round 4 output" })).toBeVisible();
  151 | 
  152 |   // New proposal on R4, refused (status 1), explicit identical retry.
  153 |   const form = await prepare(page);
  154 |   await form.getByLabel("New asset name").fill("faq");
  155 |   await form.getByLabel("Requirement").fill("Frequently asked questions");
  156 |   await form.getByRole("button", { name: "Review proposal" }).click();
  157 |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  158 |   await failureControls(page);
  159 |   await page.getByLabel("Callback outcome").selectOption("refused");
  160 |   await sponsor("Create Markdown · faq");
  161 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Callback" })).toContainText("Refused (status 1)");
  162 |   await failureControls(page);
  163 |   await page.getByLabel("Callback outcome").selectOption("bad_binding");
  164 |   const refused = page.locator("#progress > ul > li").first();
  165 |   await refused.getByRole("button", { name: "Review identical paid retry" }).click();
  166 |   await expect(funding(page).getByRole("heading", { name: "Review identical paid retry" })).toBeVisible();
  167 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  168 |   await funding(page).getByRole("button", { name: "2. Purchase identical retry" }).click();
  169 |   const retry = page.locator("#progress > ul > li").first();
  170 |   await expect(retry).toContainText("Attempt 2");
  171 |   await expect(retry.locator(".stage", { hasText: "Binding" })).toContainText("Failed");
  172 |   await retry.getByRole("button", { name: "Correct binding without purchase" }).click();
  173 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Binding" })).toContainText("Confirmed");
  174 |   await expect(page.locator("#progress > ul > li")).toHaveCount(3);
  175 |   await selectRound(page, 5);
  176 |   await expect(page.getByRole("heading", { name: "Round 5 output" })).toBeVisible();
  177 | 
  178 |   // Status 2 freezes purchases on this branch.
  179 |   await prepare(page);
  180 |   await form.getByLabel("New asset name").fill("faq2");
  181 |   await form.getByLabel("Requirement").fill("Write another note");
  182 |   await form.getByRole("button", { name: "Review proposal" }).click();
  183 |   await form.getByRole("button", { name: "Sign and submit proposal" }).click();
  184 |   await failureControls(page);
  185 |   await page.getByLabel("Callback outcome").selectOption("failed");
  186 |   await sponsor("Create Markdown · faq2");
  187 |   await expect(page.getByText("Purchases frozen", {exact:false})).toBeVisible();
  188 | });
  189 | 
  190 | test("unknown purchase reconciles by original hash/nonce after reload, never repurchases", async ({ page }) => {
  191 |   await openDemo(page, "#/demo/b/fx-branch-1");
  192 |   await failureControls(page);
  193 |   await page.getByLabel("Purchase receipt").selectOption("unknown");
  194 |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  195 |   await row.getByRole("button", { name: "Review funding" }).click();
  196 |   await disclose(page, /^Exact proposal/);
  197 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  198 |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  199 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Purchase" })).toContainText("Unknown; reconcile");
  200 |   await page.reload();
  201 |   await expect(page.getByText(/Original transaction.*purchase Confirmed/)).toBeVisible();
  202 |   await expect(page.locator("#progress > ul > li")).toHaveCount(1);
  203 | });
  204 | 
  205 | test("fork an accepted historical checkpoint copies that asset set only", async ({ page }) => {
  206 |   await openDemo(page, "#/demo/b/fx-branch-1");
  207 |   await selectRound(page, 2);
  208 |   const r2 = page.getByRole("dialog", { name: "Historical Fork" });
  209 |   await page.getByRole("button", { name: "Historical Fork", exact: true }).click();
  210 |   await r2.getByLabel("Fork direction (fixed after creation)").fill("Develop an English introduction");
  211 |   await r2.getByRole("button", { name: "Review fork" }).click();
  212 |   await expect(r2.getByText("notes@1, site@1, cover@2")).toBeVisible();
  213 |   await r2.getByRole("button", { name: "Sign and fork" }).click();
  214 |   await r2.getByRole("link", { name: "Open fork" }).click();
  215 |   await expect(page.getByText("Fork direction", { exact: false }).first()).toBeVisible();
  216 |   await disclose(page, /^Branch, network/);
  217 |   await expect(page.getByText("None / None")).toBeVisible();
  218 |   await selectFile(page, "site");
  219 |   await expect(page.locator("#assets")).toContainText("site@1");
  220 |   await expect(page.locator("#assets")).toContainText("File origin: fx-branch-1");
  221 |   await expect(page.getByText("No proposals yet", { exact: false })).toBeVisible();
  222 |   // Copied historical bytes still verify against their original producer job.
  223 |   await selectFile(page, "cover");
  224 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  225 |   await expect(page.getByRole("img", { name: "cover from round 2" })).toBeVisible();
  226 | });
  227 | 
  228 | test("workspace layout at this project's width has no horizontal scroll", async ({ page }) => {
  229 |   await openDemo(page, "#/demo/b/fx-branch-1");
  230 |   await expect(page.getByRole("heading", { name: "Relay introduction" })).toBeVisible();
  231 |   await page.getByText("Demo settings", {exact:true}).click();
  232 |   await page.evaluate(() => scrollTo(0, 0));
  233 |   await expect(page.getByRole("button", { name: /^Select Round 3,/ })).toBeInViewport({ ratio: 1 });
  234 |   await expect(page.getByText("Demo mode").first()).toBeInViewport();
  235 |   await page.screenshot({ type: "jpeg", quality: 45, scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace-first.jpg` });
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(0);
  237 |   await selectFile(page, "site");
  238 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  239 |   await page.screenshot({ scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace.jpg`, type: "jpeg", quality: 55, fullPage: false });
  240 | });
  241 | 
  242 | test("malicious files stay isolated and broken files never get a verified badge", async ({ page }) => {
  243 |   await openDemo(page, "#/demo/b/fx-branch-sec");
  244 |   const open = (key: string) => selectFile(page, key);
  245 | 
  246 |   await open("evil-site");
  247 |   const frame = page.locator("iframe.frame");
  248 |   await expect(frame).toHaveAttribute("sandbox", "");
```