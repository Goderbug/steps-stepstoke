// Supplemental synthetic history/layout check against the production export; no wallet or RPC.
import {chromium, expect} from '../../frontend/node_modules/@playwright/test/index.mjs';
import {startPreview} from '../../frontend/scripts/static-preview.mjs';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const out=resolve('evidence/rendered'),rows=[];await mkdir(out,{recursive:true});
const server=await startPreview(0),base=`http://127.0.0.1:${server.address().port}/preview/`;
const browser=await chromium.launch({executablePath:process.env.W1_CHROMIUM_EXECUTABLE});
try{
 for(const width of [1440,390,320]){
  const page=await browser.newPage({viewport:{width,height:900}}),errors=[],consoleErrors=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
  await page.goto(base);const main=page.getByRole('link',{name:'Explore demo project'});await expect(main).toBeVisible();
  const home=await main.boundingBox();assert.ok(home.y+home.height<=900,'Primary home action on first screen');
  const metadata=await page.evaluate(()=>({title:document.title,description:document.querySelector('meta[name=description]')?.content,ogTitle:document.querySelector('meta[property="og:title"]')?.content,ogImage:document.querySelector('meta[property="og:image"]')?.content,favicon:document.querySelector('link[rel=icon]')?.getAttribute('href'),x:document.querySelector('a[href="https://x.com/stepstoke"]')?.href}));
  assert.ok(Object.values(metadata).every(Boolean));
  if(width===390)await page.screenshot({path:resolve(out,'home-390.jpg'),type:'jpeg',quality:50});
  await main.click();await expect(page.getByRole('heading',{name:'Round 3 output',exact:true})).toBeVisible();await expect(page.getByText('Verified locally · SHA-256, length, media',{exact:true})).toBeVisible();
  if(width===1440)await page.screenshot({path:resolve(out,'workspace-1440.jpg'),type:'jpeg',quality:50});
  await page.evaluate(()=>{const k='platform.fixture.v1',s=JSON.parse(localStorage.getItem(k)),cp=s.checkpoints.find(c=>c.id==='fx-branch-1:3');for(let i=4;i<32;i++)s.checkpoints.push({...cp,id:'fx-branch-1:'+i,revision:i,changed:[]});s.branches.find(b=>b.id==='fx-branch-1').latestCheckpoint='fx-branch-1:31';localStorage.setItem(k,JSON.stringify(s));});
  await page.reload();await expect(page.getByRole('heading',{name:'Round 31 output',exact:true})).toBeVisible();
  const rail=page.locator('.sequence-rail');await expect(rail.locator('li')).toHaveCount(32);
  const metrics=await rail.evaluate(e=>({width:e.clientWidth,scrollWidth:e.scrollWidth,scrollLeft:e.scrollLeft,height:e.clientHeight,columns:getComputedStyle(e).gridTemplateColumns,overflowX:getComputedStyle(e).overflowX}));
  if(width===1440){assert.ok(metrics.scrollWidth>metrics.width);await page.getByRole('button',{name:'← Earlier',exact:true}).click();await expect.poll(()=>rail.evaluate(e=>e.scrollLeft)).toBeLessThan(metrics.scrollLeft);}
  const first=page.getByRole('button',{name:'Select Round 1',exact:true});await first.focus();await page.keyboard.press('Enter');await expect(page.getByRole('heading',{name:'Round 1 output',exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'Select Round 31, Latest',exact:true})).toHaveCount(1);
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);assert.equal(overflow,0);assert.deepEqual(errors,[]);assert.deepEqual(consoleErrors,[]);
  rows.push({classification:'SYNTHETIC_LAYOUT_FIXTURE_ONLY',width,metadata,primaryHomeAction:home,checkpoints:32,rail:metrics,keyboardSelected:1,latest:31,pageOverflow:overflow,pageErrors:errors,consoleErrors});
  await page.close();
 }
 await writeFile(resolve(out,'long-history.json'),JSON.stringify(rows,null,2)+'\n');console.log('PASS: 1440/390/320, primary action and metadata, 32-checkpoint rail, keyboard selected-vs-latest, no page overflow or runtime errors.');
}finally{await browser.close();await new Promise(r=>server.close(r));}
