// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {RelaySetup} from "../RelaySetup.sol";
import {RelayBranch} from "../../src/RelayBranch.sol";
import {RelayTypes as T} from "../../src/RelayTypes.sol";
import {Policy} from "../../src/libraries/Policy.sol";
contract AdvisoryRisks is RelaySetup {
 function test_deterministicRefusalOnlyAllowsIdenticalExplicitPaidRetry() public {
  uint256 id=branch.propose(_proposal(branch,T.Profile.MarkdownCreate,1),_empty());
  uint256 other=branch.propose(_proposal(branch,T.Profile.ImageCreate,2),_empty());
  bytes32 first=_pay(branch,id,_empty());vm.prank(WRITER);intake.fail(first,1,"body_refused");
  vm.prank(SPONSOR);bytes32 second=branch.retry(PRICE,_empty());vm.prank(WRITER);intake.fail(second,1,"body_refused");
  assertEq(uint256(branch.phase()),uint256(T.Phase.Refused));assertEq(branch.attemptCount(),2);
  assertEq(intake.request(first).body,intake.request(second).body);assertEq(token.balanceOf(TREASURY),2*PRICE);
  vm.expectRevert(RelayBranch.Busy.selector);branch.sponsor(other,PRICE,_empty());
 }
 function test_unpricedCompiledInActionStopsPurchaseBeforeTransfers() public {
  uint256 id=branch.propose(_proposal(branch,T.Profile.MarkdownCreate,1),_empty());
  intake.setPrice(Policy.OPEN,0);vm.prank(SPONSOR);vm.expectRevert(RelayBranch.FeeExceeded.selector);branch.sponsor(id,PRICE,_empty());
  assertEq(intake.count(),0);assertEq(token.balanceOf(TREASURY),0);
 }
}
