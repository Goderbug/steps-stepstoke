// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

interface Vm { function etch(address, bytes calldata) external; function prank(address) external; }
abstract contract Test { Vm internal constant vm = Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    function assertEq(uint256 a, uint256 b) internal pure { require(a == b, "assertEq"); } }
import {RelayFactory} from "src/RelayFactory.sol";
import {RelayBranch} from "src/RelayBranch.sol";
import {RelayEncoder} from "src/RelayEncoder.sol";
import {RelayVerifier} from "src/RelayVerifier.sol";
import {RelayTypes as T} from "src/RelayTypes.sol";
import {Policy} from "src/libraries/Policy.sol";
import {IIntake} from "src/interfaces/IIntake.sol";

contract ProofToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    function mint(address to, uint256 v) external { balanceOf[to] += v; }
    function approve(address s, uint256 v) external returns (bool) { allowance[msg.sender][s] = v; return true; }
    function transfer(address to, uint256 v) external returns (bool) {
        balanceOf[msg.sender] -= v; balanceOf[to] += v; return true;
    }
    function transferFrom(address f, address to, uint256 v) external returns (bool) {
        allowance[f][msg.sender] -= v; balanceOf[f] -= v; balanceOf[to] += v; return true;
    }
}

contract ProofIntake is IIntake {
    uint256 public count;
    function priceOf(bytes32, address) external pure returns (uint256) { return 0.5 ether; }
    function requestWithFailure(bytes32, bytes calldata body, Callback calldata, bytes4, address asset, uint256 amount)
        external payable returns (bytes32 id)
    {
        require(body.length != 0 && amount == 0.5 ether);
        ProofToken(asset).transferFrom(msg.sender, address(0xC0FE), amount);
        id = keccak256(abi.encode(address(this), ++count, msg.sender));
    }
}

/// A real plane result that lists the declared output plus one extra produced file
/// (shape of test/fixtures/public/observed-multiple-files.json) must not brick the branch.
contract MultiFileResultProof is Test {
    address constant SPONSOR = address(0xB0B);

    function test_declaredOutputBindsWhenPlaneListsAnExtraFile() public {
        vm.etch(Policy.IMD, address(new ProofToken()).code);
        vm.etch(Policy.INTAKE, address(new ProofIntake()).code);
        ProofToken token = ProofToken(Policy.IMD);
        RelayFactory factory = new RelayFactory(new RelayEncoder(), new RelayVerifier());
        RelayBranch branch = factory.createProject("Maintain a public relay project.");
        token.mint(SPONSOR, 10 ether);
        vm.prank(SPONSOR);
        token.approve(address(branch), 10 ether);

        T.Proposal memory p;
        p.anchor = branch.anchor();
        p.profile = T.Profile.MarkdownCreate;
        p.target = bytes32(uint256(1));
        p.inputs = new bytes32[](0);
        p.outputName = "main";
        p.outputPath = "artifacts/main.md";
        p.text = "Perform the declared change.";
        T.Asset[] memory none = new T.Asset[](0);
        uint256 id = branch.propose(p, none);
        vm.prank(SPONSOR);
        bytes32 request = branch.sponsor(id, 10 ether, none);

        bytes memory raw = bytes(
            '{"jobId":"26dd9a07-601b-53bb-b203-cb1ed36889fa","projectId":"8e9b7a0c-734a-53f5-b219-5c7746b04229","state":"completed","launch":null,"delivery":{"repoUrl":"https://example.invalid/x","commit":"abc"},"source":[],"files":[{"name":"main","path":"artifacts/main.md","hash":"f32b9679cf9534a4ba9966948ce4a7900b9e0c84af7bdfeeca432bd06bbace0c","mediaType":"text/markdown","bytes":183,"submissionHash":"7487f2ea3e1407724d71e7109d677762b84d239fba2170216c66366a1b279f5a"},{"name":"data","path":"artifacts/data.json","hash":"a32b9679cf9534a4ba9966948ce4a7900b9e0c84af7bdfeeca432bd06bbace0c","mediaType":"application/json","bytes":40,"submissionHash":"7487f2ea3e1407724d71e7109d677762b84d239fba2170216c66366a1b279f5a"}]}'
        );
        vm.prank(Policy.INTAKE);
        branch.onIntakeResult(request, keccak256(raw), "ipfs://fixture/result.json");
        assertEq(uint256(branch.phase()), uint256(T.Phase.ResultRecorded));

        // Expected: the exact raw bytes bind the declared output (extra file ignored, never stripped).
        // Actual on current code: Policy.Invalid at RelayVerifier.sol:37 and the branch is stuck forever.
        branch.bind(raw, none);
        assertEq(uint256(branch.phase()), uint256(T.Phase.Ready));
        assertEq(branch.revision(), 1);
    }
}