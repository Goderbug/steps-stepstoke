import { chromium } from '<test-mirror>/frontend/node_modules/playwright/index.mjs';
import {startPreview} from '<repository>/frontend/scripts/static-preview.mjs';
import {writeFile,mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
const server=await startPreview(0),url=`http://127.0.0.1:${server.address().port}/preview/`;
const browser=await chromium.launch();const rows=[];
try {
 for(const width of [1440,390,320]){
  const page=await browser.newPage({viewport:{width,height:900}});const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url+'#/demo/b/fx-branch-1');await page.getByRole('heading',{name:'Round 3 output',exact:true}).waitFor();
  await page.evaluate(()=>{const k='platform.fixture.v1';const s=JSON.parse(localStorage.getItem(k));const cp=s.checkpoints.find(c=>c.id==='fx-branch-1:3');for(let i=4;i<32;i++)s.checkpoints.push({...cp,id:'fx-branch-1:'+i,revision:i,changed:[]});const b=s.branches.find(b=>b.id==='fx-branch-1');b.latestCheckpoint='fx-branch-1:31';localStorage.setItem(k,JSON.stringify(s));});
  await page.reload();await page.getByRole('heading',{name:'Round 31 output',exact:true}).waitFor();
  const rail=page.locator('.sequence-rail');assert.equal(await rail.locator('li').count(),32);
  const before=await rail.evaluate(el=>({width:el.clientWidth,scrollWidth:el.scrollWidth,scrollLeft:el.scrollLeft,height:el.clientHeight,overflowX:getComputedStyle(el).overflowX,columns:getComputedStyle(el).gridTemplateColumns}));
  if(width===1440){assert.ok(before.scrollWidth>before.width);await page.getByRole('button',{name:'← Earlier',exact:true}).click();await page.waitForTimeout(250);assert.ok(await rail.evaluate(el=>el.scrollLeft)<before.scrollLeft);}
  const first=page.getByRole('button',{name:'Select Round 1',exact:true});await first.focus();await page.keyboard.press('Enter');await page.getByRole('heading',{name:'Round 1 output',exact:true}).waitFor();
  assert.ok(await page.getByRole('button',{name:'Select Round 31, Latest',exact:true}).count());
  const row={classification:'SYNTHETIC_LAYOUT_FIXTURE_ONLY',width,checkpoints:32,rail:before,selectedByKeyboard:1,pageOverflow:await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth),pageErrors:errors};
  assert.equal(row.pageOverflow,0);assert.deepEqual(errors,[]);rows.push(row);await page.close();
 }
 await writeFile('<repository>/test/scratch/long-history.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
}finally{await browser.close();await new Promise(r=>server.close(r));}
