# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: w1.spec.ts >> keyboard: skip link, focus ring, connect sheet traps and restores focus
- Location: tests/e2e/w1.spec.ts:285:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('link', { name: 'Skip to main content' })
Expected: focused
Received: inactive
Timeout:  15000ms

Call log:
  - Expect "toBeFocused" getByRole('link', { name: 'Skip to main content' }) with timeout 15000ms
  - waiting for getByRole('link', { name: 'Skip to main content' })
    33 × locator resolved to <a class="skip" href="#main">Skip to main content</a>
       - unexpected value "inactive"

```

```yaml
- link "Skip to main content":
  - /url: "#main"
```

# Test source

```ts
  188 | });
  189 | 
  190 | test("unknown purchase reconciles by original hash/nonce after reload, never repurchases", async ({ page }) => {
  191 |   await openDemo(page, "#/demo/b/fx-branch-1");
  192 |   await failureControls(page);
  193 |   await page.getByLabel("Purchase receipt").selectOption("unknown");
  194 |   const row = page.locator("#proposals li", { hasText: "Update Markdown · notes" });
  195 |   await row.getByRole("button", { name: "Review funding" }).click();
  196 |   await disclose(page, /^Exact proposal/);
  197 |   await funding(page).getByRole("button", { name: "1. Approve exact amount" }).click();
  198 |   await funding(page).getByRole("button", { name: "2. Purchase execution" }).click();
  199 |   await expect(page.locator("#progress > ul > li").first().locator(".stage", { hasText: "Purchase" })).toContainText("Unknown; reconcile");
  200 |   await page.reload();
  201 |   await expect(page.getByText(/Original transaction.*purchase Confirmed/)).toBeVisible();
  202 |   await expect(page.locator("#progress > ul > li")).toHaveCount(1);
  203 | });
  204 | 
  205 | test("fork an accepted historical checkpoint copies that asset set only", async ({ page }) => {
  206 |   await openDemo(page, "#/demo/b/fx-branch-1");
  207 |   await selectRound(page, 2);
  208 |   const r2 = page.getByRole("dialog", { name: "Historical Fork" });
  209 |   await page.getByRole("button", { name: "Historical Fork", exact: true }).click();
  210 |   await r2.getByLabel("Fork direction (fixed after creation)").fill("Develop an English introduction");
  211 |   await r2.getByRole("button", { name: "Review fork" }).click();
  212 |   await expect(r2.getByText("notes@1, site@1, cover@2")).toBeVisible();
  213 |   await r2.getByRole("button", { name: "Sign and fork" }).click();
  214 |   await r2.getByRole("link", { name: "Open fork" }).click();
  215 |   await expect(page.getByText("Fork direction", { exact: false }).first()).toBeVisible();
  216 |   await disclose(page, /^Branch, network/);
  217 |   await expect(page.getByText("None / None")).toBeVisible();
  218 |   await selectFile(page, "site");
  219 |   await expect(page.locator("#assets")).toContainText("site@1");
  220 |   await expect(page.locator("#assets")).toContainText("File origin: fx-branch-1");
  221 |   await expect(page.getByText("No proposals yet", { exact: false })).toBeVisible();
  222 |   // Copied historical bytes still verify against their original producer job.
  223 |   await selectFile(page, "cover");
  224 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  225 |   await expect(page.getByRole("img", { name: "cover from round 2" })).toBeVisible();
  226 | });
  227 | 
  228 | test("workspace layout at this project's width has no horizontal scroll", async ({ page }) => {
  229 |   await openDemo(page, "#/demo/b/fx-branch-1");
  230 |   await expect(page.getByRole("heading", { name: "Relay introduction" })).toBeVisible();
  231 |   await page.getByText("Demo settings", {exact:true}).click();
  232 |   await page.evaluate(() => scrollTo(0, 0));
  233 |   await expect(page.getByRole("button", { name: /^Select Round 3,/ })).toBeInViewport({ ratio: 1 });
  234 |   await expect(page.getByText("Demo mode").first()).toBeInViewport();
  235 |   await page.screenshot({ type: "jpeg", quality: 45, scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace-first.jpg` });
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(0);
  237 |   await selectFile(page, "site");
  238 |   await expect(page.getByText("Verified locally · SHA-256, length, media")).toBeVisible();
  239 |   await page.screenshot({ scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-workspace.jpg`, type: "jpeg", quality: 55, fullPage: false });
  240 | });
  241 | 
  242 | test("malicious files stay isolated and broken files never get a verified badge", async ({ page }) => {
  243 |   await openDemo(page, "#/demo/b/fx-branch-sec");
  244 |   const open = (key: string) => selectFile(page, key);
  245 | 
  246 |   await open("evil-site");
  247 |   const frame = page.locator("iframe.frame");
  248 |   await expect(frame).toHaveAttribute("sandbox", "");
  249 |   await expect(page.frameLocator("iframe.frame").locator("#evil")).toHaveText("Hostile HTML fixture");
  250 |   await page.waitForTimeout(500);
  251 |   expect(await page.evaluate(() => localStorage.getItem("w1.pwned"))).toBeNull();
  252 |   expect(page.url()).toContain("#/demo/b/fx-branch-sec");
  253 |   expect(await page.title()).not.toBe("SCRIPT_RAN");
  254 |   expect(page.context().pages()).toHaveLength(1);
  255 | 
  256 |   await open("evil-notes");
  257 |   await expect(page.locator(".md h1")).toHaveText("Hostile Markdown fixture");
  258 |   expect(await page.evaluate(() => (window as unknown as Record<string, unknown>).__mdScriptRan ?? (window as unknown as Record<string, unknown>).__mdOnerror ?? null)).toBeNull();
  259 |   await expect(page.locator(".md script, .md img, .md iframe")).toHaveCount(0);
  260 |   await expect(page.locator(".md a", { hasText: "Unsafe link" })).not.toHaveAttribute("href", /.*/);
  261 |   await expect(page.locator(".md a", { hasText: "Safe HTTPS link" })).toHaveAttribute("rel", "noopener noreferrer nofollow");
  262 | 
  263 |   await open("tampered");
  264 |   await expect(page.locator("#assets").getByText("SHA-256: Fail")).toBeVisible();
  265 |   await expect(page.locator("#assets").getByRole("link", { name: "Download verified file" })).toHaveCount(0);
  266 | 
  267 |   await open("missing");
  268 |   await expect(page.getByText("File unavailable: File unavailable (404)", { exact: false })).toBeVisible();
  269 | 
  270 |   await open("fake-png");
  271 |   await expect(page.locator("#assets").getByText(/Format: Fail/)).toBeVisible();
  272 |   await expect(page.locator("#assets").locator("img")).toHaveCount(0);
  273 |   await open("broken-png");
  274 |   const broken = page.locator("#assets");
  275 |   await expect(broken).toContainText("Image decode: Fail");
  276 |   await expect(broken.getByText("Verified locally · SHA-256, length, media")).toHaveCount(0);
  277 |   await expect(broken.locator("img, a[download]")).toHaveCount(0);
  278 |   await open("oversized-png");
  279 |   const oversized = page.locator("#assets");
  280 |   await expect(oversized).toContainText("Image resource limit: Fail");
  281 |   await expect(oversized.locator("img, a[download]")).toHaveCount(0);
  282 |   await page.screenshot({ scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-security.jpg`, type: "jpeg", quality: 55, fullPage: false });
  283 | });
  284 | 
  285 | test("keyboard: skip link, focus ring, connect sheet traps and restores focus", async ({ page }) => {
  286 |   await page.goto("./");
  287 |   await page.keyboard.press("Tab");
> 288 |   await expect(page.getByRole("link", { name: "Skip to main content" })).toBeFocused();
      |                                                                          ^ Error: expect(locator).toBeFocused() failed
  289 |   const connect = page.getByRole("button", { name: "Connect wallet" });
  290 |   await connect.focus();
  291 |   const outline = await connect.evaluate((el) => getComputedStyle(el).outlineStyle);
  292 |   expect(outline).toBe("solid");
  293 |   await page.keyboard.press("Enter");
  294 |   const dialog = page.getByRole("dialog", { name: "Connect wallet" });
  295 |   await expect(dialog).toBeVisible();
  296 |   await expect(dialog.locator(":focus")).toHaveCount(1);
  297 |   await page.keyboard.press("Escape");
  298 |   await expect(dialog).toHaveCount(0);
  299 |   await expect(connect).toBeFocused();
  300 |   await page.screenshot({ type: "jpeg", quality: 45, scale: "css", path: `../test/scratch/regression-screenshots/${test.info().project.name}-live.jpg` });
  301 | });
  302 | 
```