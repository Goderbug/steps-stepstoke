// Disposable browser test: public reads only. Serves exactly one module and a blank test page.
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { once } from 'node:events';
process.env.PLAYWRIGHT_BROWSERS_PATH=new URL('../../overnight-release-v1/evidence/candidate-20261021T224531Z/frontend-review/browsers',import.meta.url).pathname;
const {chromium,webkit}=await import('../source/frontend/node_modules/playwright/index.mjs');
const source=await readFile(new URL('../source/sdk/public-rpc.mjs',import.meta.url));
const server=createServer((req,res)=>{
  if(req.url==='/sdk/public-rpc.mjs'){res.writeHead(200,{'content-type':'text/javascript'});res.end(source);}
  else if(req.url==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><html lang="en"><title>Disposable read-only CORS test</title></html>');}
  else{res.writeHead(404);res.end();}
});
server.listen(0,'127.0.0.1');await once(server,'listening');
const origin=`http://127.0.0.1:${server.address().port}`;const observations=[];
try {
  for(const[name,engine]of Object.entries({chromium,webkit})){
    const browser=await engine.launch({headless:true});
    try{
      const page=await browser.newPage();await page.goto(origin);
      const result=await page.evaluate(async()=>{
        const {createPublicReadProvider}=await import('/sdk/public-rpc.mjs');
        const calls=[];
        const provider=createPublicReadProvider({fetch:async(url,init)=>{
          const request=JSON.parse(init.body),entry={url,method:request.method};calls.push(entry);
          const response=await fetch(url,init);entry.httpStatus=response.status;return response;
        }});
        const outcomes=[];
        for(const[method,params]of [['eth_chainId',[]],['debug_traceTransaction',['0x8c4a38b4f3dfef00df652188d4925c345bb25a4cf29dab5aae057c797c215770',{tracer:'callTracer'}]],['eth_getCode',['0xa43e6f75ee006411f79ac1c84120606c2330de82','0x1906b58']]]){
          try{const r=await provider.request({method,params});outcomes.push({method,ok:true,result:typeof r==='string'?{length:r.length,prefix:r.slice(0,50)}:{type:r.type,from:r.from,to:r.to,calls:r.calls?.length,error:r.error??null}});}
          catch(e){outcomes.push({method,ok:false,error:e.message});}
        }
        return {outcomes,calls};
      });
      observations.push({browser:name,...result});
    }finally{await browser.close();}
  }
}finally{server.close();}
const result={observedAt:new Date().toISOString(),classification:'REAL_BROWSER_ANONYMOUS_PUBLIC_READS_ONLY',origin,finalHostingOriginTested:false,noDeployment:true,productionReady:false,liveCompatibility:'NOT_RUN',observations};
await writeFile(new URL('public-browser-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
if(observations.some(o=>o.outcomes.some(r=>!r.ok)))process.exitCode=1;
