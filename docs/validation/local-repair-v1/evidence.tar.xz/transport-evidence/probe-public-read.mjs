// Read-only, anonymous capability probe against EXISTING public activity, never a deployment.
import { createPublicReadProvider } from '../source/sdk/public-rpc.mjs';
import { writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const calls=[];
const trackedFetch=async(url,init)=>{
  const {method,params}=JSON.parse(init.body), entry={url,method,params,at:new Date().toISOString()};calls.push(entry);
  const r=await fetch(url,{...init,headers:{...init.headers,Origin:'https://stepstoke.example'}});
  entry.status=r.status;entry.allowOrigin=r.headers.get('access-control-allow-origin');
  const text=await r.clone().text();
  entry.bytes=Buffer.byteLength(text);entry.sha256=createHash('sha256').update(text).digest('hex');
  try{const b=JSON.parse(text);entry.error=b.error??null;entry.resultPresent=b.result!==undefined&&b.result!==null;}catch{entry.nonJSON=true;}
  await writeFile(new URL(`probe-${calls.length}-${method}.json`,import.meta.url),text);
  return r;
};
const p=createPublicReadProvider({fetch:trackedFetch}),observations=[];
const requests=[
  ['eth_chainId',[]],
  ['debug_traceTransaction',['0x8c4a38b4f3dfef00df652188d4925c345bb25a4cf29dab5aae057c797c215770',{tracer:'callTracer'}]],
  ['eth_getCode',['0xa43e6f75ee006411f79ac1c84120606c2330de82','0x1906b58']]
];
for(const[method,params]of requests){
  try{const result=await p.request({method,params});
    const summary=typeof result==='string'?{length:result.length,prefix:result.slice(0,50)}:{type:result.type,from:result.from,to:result.to,calls:result.calls?.length,error:result.error??null};
    const observation={method,ok:true,summary};
    if(method==='eth_getCode'){
      const prior=JSON.parse(await readFile(new URL('../../overnight-release-v1/evidence/candidate-20261021T224531Z/sdk-review/transport-investigation/drpc-eth_getCode.txt',import.meta.url),'utf8')).result;
      observation.matchesPriorCapturedIntakeCode=result===prior;
      observation.codeSha256=createHash('sha256').update(Buffer.from(result.slice(2),'hex')).digest('hex');
    }
    observations.push(observation);
  }catch(e){observations.push({method,ok:false,error:e.message});}
}
const output={checkedAt:new Date().toISOString(),classification:'ANONYMOUS_READ_ONLY_EXISTING_CHAIN_ACTIVITY',rpcUrls:p.rpcUrls,noDeployment:true,productionReady:false,liveCompatibility:'NOT_RUN',observations,calls};
await writeFile(new URL('public-read-probe.json',import.meta.url),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
