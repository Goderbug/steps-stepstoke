# F1 local public-read transport repair

Checked 2026-10-22 04:41 UTC. No wallet, signature, paid order, key registration, deployment, hosted site or public write was used.

## Change

Added the shared browser/Node `sdk/public-rpc.mjs` read-only transport. Its bounded, explicit endpoint list defaults to PublicNode followed by dRPC; the importer emits it as separately SHA-256-inventoried `public-read-transport.json`. The official handoff `network` and `walletAddChain` values remain unchanged. The browser handoff loader authenticates that policy using the same final asset inventory, with no URL parameter, browser storage or user-form endpoint injection. Public ChainAdapter, the importer and the read-only observer consume the shared transport; local-chain transport is unchanged.

Availability errors (network/timeouts, HTTP failures, unsupported RPC methods, selected rate/archive errors) can use another listed endpoint. Successful null/empty/malformed semantic data does not cause failover. Wrong chain, malformed JSON-RPC envelopes, execution reverts and verifier failures stop. The full existing source/ABI/receipt/block/CREATE/historical-code/runtime/immutable/constructor checks are retained, with an additional final receipt/block canonicality check. A downloaded trace file is never a substitute for live verification.

## Evidence

- `sdk-tests.log`: 84/84 SDK tests pass. Thirteen new tests cover bounded policy, unsupported-method/archive/HTTP failover, fallback chain checks, no signing methods, semantic no-fallback, malformed envelopes, timeout/response size, real deployment-verifier paths with synthetic evidence, tampered source/creation/constructor/runtime/receipt rejection, reorg rejection and policy-byte tampering. These are local synthetic tests, not live product acceptance.
- `public-read-probe.json` and `probe-*.json`: anonymous Node reads at 04:41:05 UTC, repeated after the final error-classification fix. Existing candidate-order transaction `0x8c4a38b4f3dfef00df652188d4925c345bb25a4cf29dab5aae057c797c215770`; historical Intake `0xa43e6f75ee006411f79ac1c84120606c2330de82` at block `0x1906b58`. PublicNode returned trace error -32601 and historical-code HTTP 403. The actual repaired provider selected dRPC, received a 33,600-byte callTracer response, and returned the 7,384-byte Intake runtime equal to the prior independently captured bytes. Runtime SHA-256: `f5fff211a739f75cd4dd1f4b16b713c2d52fb9c146d378db27194ffc4a3327bb`.
- `public-browser-probe.json`: actual Chromium and WebKit browser reads at 04:34:27 UTC, from an isolated local HTTP test origin. Both used the repaired module and successfully read chain ID, the existing transaction trace and historical Intake code through the same real PublicNode failures and dRPC fallback. This exercises browser CORS without keys or a proxy. It does not test the future hosting origin or future deployment.

The first Node probe ran inside the network-restricted sandbox and could not reach either endpoint. The authorized read-only external-network run above is the retained completed observation. No failed probe was treated as a deployment result.

Independent review found that generic JSON-RPC -32603 can wrap a semantic revert. That fallback was removed. Flat and nested reverts, generic internal errors, malformed error objects and identity mismatches now fail closed even with HTTP 500; error bodies use the same byte/time bounds. Only a plain HTTP availability response or an explicitly recognized availability error can fall back. The exact PublicNode HTTP 403 archive-tier denial remains supported. The final 84-test run includes both non-2xx semantic regressions and response-stream interruption recovery. The earlier browser probe predates this conservative classification change; the final Node probe confirms the real archive/trace path still works, and the frontend reviewer owns the final rebuilt browser bundle validation.

## Remaining launch gate

The full importer rehearsal depends on a real Git source pin and regenerated final compiler metadata, so it is deferred to the root agent's final freeze/rehearsal stage. No sourceCommit, receipt or attestation was fabricated for this patch.

Before website publication, use the actual IMD three-contract handoff and final source commit. Run importer, observer and final-origin browser verification against the actual deployment transaction. `productionDeployment` remains null; `productionReady` remains false; `liveCompatibility` remains NOT_RUN here.

The fallback is not a service-level guarantee. The current [dRPC debug_traceTransaction documentation](https://drpc.org/docs/ethereum-api/debugandtrace/debug_traceTransaction), freshly inspected this turn, labels the method as paid-tier while showing the anonymous endpoint example. Our anonymous access is a time-stamped observation only. If all listed endpoints stop providing required historical/trace reads, the app must remain unavailable rather than weaken verification. Public RPCs remain trusted data providers; this patch does not create a quorum or cryptographic execution proof.

## Changed files

- `sdk/public-rpc.mjs` (new)
- `sdk/handoff.mjs`
- `sdk/deployment.mjs`
- `sdk/browser.mjs`
- `sdk/index.mjs`
- `tools/import-deployment.mjs`
- `tools/observe-ethereum.mjs`
- `frontend/src/domain/chainAdapter.ts`
- `test-sdk/public-rpc.test.mjs` (new)
- `docs/HANDOFF.md`

No Solidity, generated ABI, release fingerprint, production gate, original review or paid-order state was changed by this subtask.
