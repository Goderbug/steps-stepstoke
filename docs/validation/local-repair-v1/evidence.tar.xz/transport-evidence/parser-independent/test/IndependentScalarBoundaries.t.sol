// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ManifestStringHarness} from "./ManifestStringRegression.t.sol";
import {TestBase} from "./TestBase.sol";
contract IndependentScalarBoundariesTest is TestBase {
    ManifestStringHarness p;
    function setUp() public { p = new ManifestStringHarness(); }
    function raw(uint256 c) private pure returns (bytes memory) {
        if(c<128)return abi.encodePacked(bytes1(uint8(c)));
        if(c<2048)return abi.encodePacked(bytes1(uint8(0xc0|(c>>6))),bytes1(uint8(0x80|(c&63))));
        if(c<65536)return abi.encodePacked(bytes1(uint8(0xe0|(c>>12))),bytes1(uint8(0x80|((c>>6)&63))),bytes1(uint8(0x80|(c&63))));
        return abi.encodePacked(bytes1(uint8(0xf0|(c>>18))),bytes1(uint8(0x80|((c>>12)&63))),bytes1(uint8(0x80|((c>>6)&63))),bytes1(uint8(0x80|(c&63))));
    }
    function u16(uint256 c) private pure returns (bytes memory) {
        bytes16 a='0123456789abcdef'; return abi.encodePacked(bytes2('\\u'),a[(c>>12)&15],a[(c>>8)&15],a[(c>>4)&15],a[c&15]);
    }
    function escaped(uint256 c) private pure returns(bytes memory){
        if(c<65536)return u16(c);uint256 n=c-65536;return bytes.concat(u16(0xd800+(n>>10)),u16(0xdc00+(n&1023)));
    }
    function check(bytes memory value,bool accepted) private view {
        bytes memory retained=bytes.concat('{"state":"',value,'"}');
        bytes memory ignored=bytes.concat('{"state":"ok","unknown":"',value,'"}');
        (bool a,bytes memory v)=address(p).staticcall(abi.encodeCall(p.field,(retained)));
        (bool b,bytes memory w)=address(p).staticcall(abi.encodeCall(p.referenceField,(retained)));
        assertTrue(a==accepted);assertTrue(a==b);if(a)assertEq(v,w);
        (bool c,)=address(p).staticcall(abi.encodeCall(p.field,(ignored)));assertTrue(c==accepted);
    }
    function test_allUnicodePlaneNoncharactersRejectedAndAdjacentScalarsAccepted() public view {
        for(uint256 plane;plane<17;++plane){
            for(uint256 low=0xfffe;low<=0xffff;++low){uint256 c=(plane<<16)|low;check(raw(c),false);check(escaped(c),false);}
            uint256 adjacent=(plane<<16)|0xfffd;check(raw(adjacent),true);check(escaped(adjacent),true);
        }
        for(uint256 c=0xfdd0;c<=0xfdef;++c){check(raw(c),false);check(escaped(c),false);}
        check(raw(0xfdcf),true);check(escaped(0xfdcf),true);check(raw(0xfdf0),true);check(escaped(0xfdf0),true);
    }
    function test_scratchKeyDecodePreservesDigestAcrossNestedUnicodeKeys() public view {
        bytes memory input=bytes(unicode'{"state":"Aé水🚀","meta":{"é":"ok"},"other":{"\\u00e9":"ok"},"jobId":"hello"}');
        assertEq(p.field(input),p.referenceField(input));
    }
    function test_duplicatesAcrossRawEscapedSupplementaryKeysReject() public view {
        bytes memory input=bytes(unicode'{"state":"ok","🚀":1,"\\ud83d\\ude80":2}');
        (bool ok,)=address(p).staticcall(abi.encodeCall(p.field,(input)));assertTrue(!ok);
    }
    function test_all256SimpleEscapeBytesMatchStrictReference() public view {
        for(uint256 b;b<256;++b){
            bool accepted=b==34||b==47||b==92||b==98||b==102||b==110||b==114||b==116;
            check(abi.encodePacked(bytes1(0x5c),bytes1(uint8(b))),accepted);
            check(bytes.concat("\\n\\t\\b",abi.encodePacked(bytes1(0x5c),bytes1(uint8(b)))),accepted);
        }
    }
    function test_simpleEscapeRunTransitionsToUnicodeRawAndEOF() public view {
        check(bytes.concat("\\n\\t\\b","\\u00e9",unicode"水","\\r\\f","\\uD83D\\uDE80","end"),true);
        check(bytes.concat("\\n\\t",bytes(hex"f4908080")),false);
        bytes memory missing=bytes('{"state":"\\n\\t\\');
        (bool ok,)=address(p).staticcall(abi.encodeCall(p.field,(missing)));assertTrue(!ok);
        (bool ref,)=address(p).staticcall(abi.encodeCall(p.referenceField,(missing)));assertTrue(!ref);
    }
    function test_simpleEscapeRunDecodedLimitAndUnicodeTransition() public view {
        bytes memory value=new bytes(2046);
        for(uint256 i;i<value.length;i+=2){value[i]=0x5c;value[i+1]='n';}
        check(bytes.concat(value,"\\u0000"),true);
        check(bytes.concat(value,"\\t"),true);
        bytes[3] memory over=[bytes.concat(value,"\\t\\t"),bytes.concat(value,"\\u00e9"),bytes.concat(value,unicode"é")];
        for(uint256 i;i<over.length;++i){
            bytes memory input=bytes.concat('{"state":"',over[i],'"}');
            (bool ok,)=address(p).staticcall(abi.encodeCall(p.field,(input)));assertTrue(!ok);
            (bool ref,)=address(p).staticcall(abi.encodeCall(p.referenceField,(input)));assertTrue(!ref);
        }
    }
}
