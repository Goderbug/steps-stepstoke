# Independent retained-string parser review

Reviewed 2026-10-22 04:43 UTC. Product source was read only. Tests used a separate copied source tree and separate compiler outputs under `parser-independent/`; shared `source/out` and `source/cache` were not touched.

Reviewed file: `src/libraries/ManifestJSON.sol`.
SHA-256: `dfa6ac692a8113e25d04ad2320d38646424c28223041e4b24d6ebd3c07c5f2fc`.
The tested copy and final shared source had identical hashes after the run.

## Result

No actionable correctness finding in the reviewed parser change. This is a bounded independent code review and differential test result, not a formal audit or proof of the complete accepted-input gas envelope.

The raw UTF-8 width classifier retains overlong, continuation-byte, surrogate, noncharacter and greater-than-U+10FFFF rejection. Its four-byte noncharacter predicate corresponds to the final sixteen scalar bits equal to FFFE/FFFF. Escaped surrogate pairs retain exact hex validation, required low-surrogate bounds and scalar validation. The packed hex decoder validates each ASCII digit before combining its low nibble with the alphabetic offset. The simple-escape lookup has only the eight JSON escape values; an unknown byte or incomplete Unicode escape returns to the general reject path.

The new consecutive-simple-escape loop checks two input bytes remain, writes only when decoded length is below the fixed allocation, advances exactly two raw bytes per accepted escape and stops without consuming Unicode, unknown or raw text. Raw segment flushes require `decoded length + segment size <= max`. Zero-length flush removal preserves that invariant because prior writes already established `decoded length <= max`. Lookahead loads can contain bytes beyond the active input, but only explicitly length-checked bytes can affect acceptance. Input length is bounded by the unchanged manifest envelope, so position arithmetic cannot approach uint256 overflow.

The output buffers are separately allocated retained strings or the existing fixed key scratch buffer; raw manifest memory is not written. Key bytes are hashed after decoding, and retained keys are copied before recursive parsing can reuse the scratch buffer. Duplicate-key identity therefore remains based on decoded bytes, including raw versus escaped Unicode representations. The outer verifier's `keccak256(raw) == recordedHash` check is unchanged. No parser resource constant or work charge was reduced.

## Executed checks

`parser-independent-tests.log`: Solidity 0.8.26, original optimizer/via-IR/Cancun settings, 13 tests passed; zero failed/skipped. Three differential fuzz tests executed 1,000 cases each against unchanged StrictJSON/Text logic. Six independently added tests exercised:

- All 256 possible simple-escape bytes both standalone and following a consecutive escape run, with exact acceptance/output comparison to StrictJSON.
- Every Unicode plane's FFFE/FFFF noncharacters, every FDD0–FDEF noncharacter, and adjacent valid scalars, using both raw UTF-8 and escaped representations in retained and ignored strings.
- Raw/escaped supplementary duplicate keys and nested scratch-key reuse.
- Simple-escape runs followed by Unicode escapes, raw multibyte text, invalid UTF-8 or a trailing backslash/EOF.
- 1,024 decoded bytes accepted and 1,025 rejected after simple-escape or Unicode transitions.

`parser-formula-check.json`: independent arithmetic comparison of all 234,256 four-digit mixed-case hexadecimal combinations and all 256 simple-escape lookup entries. This is a formula cross-check, explicitly separate from EVM execution.

The initial independent run checked an earlier snapshot; the final log above supersedes it and is pinned to the final hash. Aggregate gas printed for tests that loop over hundreds of adversarial cases is test-harness cost, not a claimed product transaction gas figure. The root agent's full original-transaction replay and the contract agent's gas-shape regression results remain necessary for gas acceptance.
