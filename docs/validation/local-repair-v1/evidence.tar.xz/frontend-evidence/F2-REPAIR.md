# F2 — local interaction repair

Scope: repair the delivered candidate's keyboard and dialog focus defects in the new isolated `steps-local-repair-v1/source` tree. Public/fixture/local modes, wallet entry points, paid-action gates, file verification and HTML/Markdown isolation remain in place. No production signing, funded testing, deployment, hosting or paid IMD order is part of this work.

## Changes

- `frontend/src/components/Sheet.tsx`: capture an explicitly supplied initiating control when the sheet mounts. A pointer activation in WebKit need not update `document.activeElement`; dismissal now returns focus to the actual trigger. The previous active element remains a fallback for a programmatic sheet without an explicit trigger. Disconnected elements are not focused.
- `frontend/src/components/FundingSheet.tsx`, `frontend/src/ui/Workspace.tsx`, `frontend/src/ui/Showcase.tsx`: pass the actual `event.currentTarget` for Continue, proposal funding, stale proposal preparation, historical fork, identical paid retry and showcase funding. No signing or funding flow changed.
- `frontend/src/App.tsx`: make the first skip link an explicit `tabIndex=0` stop. The existing native Enter activation still transfers focus to main content.
- `frontend/src/preview/FilePreview.tsx`: handle ArrowLeft/ArrowRight/Home/End only when the actual focused target is the application-generated overflow-table region. Modified keys and links inside the document are left alone. Content remains sanitized before wrappers are added; no inline handlers or file-provided scripts are introduced.

## Diagnosis

`keyboard-diagnostic.json` records a standalone real-browser test on the unchanged installed engines. With default WebKit preferences, the first Tab skipped a native anchor and focused the input; an explicit zero tabindex made that same anchor the first stop. A focused overflow region did not scroll on ArrowRight in WebKit, while Chromium scrolled by 40 pixels. This is why the fix improves the application behavior directly. Browser accessibility preferences and system defaults were not changed.

The local sandbox initially prevented WebKit from launching. The same cached browser was then launched with the approved external process permission for local testing. An exploratory attempt to pass a macOS keyboard preference as raw launch arguments was rejected by Playwright before launch; it is not part of the source or successful test configuration.

## Regression coverage

- Existing Continue and showcase Escape-dismissal assertions retained.
- New browser regression deliberately focuses an unrelated header control, then clicks each contribution trigger and dismisses its sheet. It verifies the correct trigger regains focus and the background is no longer inert.
- Existing first-Tab skip-link assertion retained and extended to press Enter and verify main-content focus.
- Existing wide-table overflow/layout/download/ArrowRight assertions retained and extended to verify ArrowLeft, Home and End.
- No force click, skipped case, deleted assertion or synthetic successful outcome is used.

## Results

The full fixture matrix passed **185/185**, with **0 failures, 0 skips and 0 flaky results** (37 cases in each of five projects), including all eight originally failing WebKit cases. It completed at approximately 2026-10-22 04:34:32 UTC. The targeted WebKit run passed 8/8 cases, the existing frontend unit suite passed 100/100 on Node 24.19.0, TypeScript passed, and the production build passed. See `full.json`, `full.log`, `targeted.json`, `unit.log`, `typecheck.log` and `build-integrated.log`.

The full matrix uses the original five projects (Chromium desktop/mobile/320px; WebKit desktop/mobile) and real cached Playwright 1.64.1 browser binaries. Chromium uses its supported executable override to the full Chrome-for-Testing 1248 binary because the previously diagnosed headless-shell build on this host does not emit normal animation frames. WebKit 2370 uses its default launch settings. All browser journeys use local fixture data; this is not live IMD acceptance or a mainnet deployment test.

The existing tests also emit screenshots and diagnostics into hardcoded source-relative directories. Those generated files were copied to `fixture-evidence/`; only those output directories were then restored to the original candidate baseline. `F2-REPAIR.json` records all nine intentional frontend source/test changes and the exact tested production export hashes.
