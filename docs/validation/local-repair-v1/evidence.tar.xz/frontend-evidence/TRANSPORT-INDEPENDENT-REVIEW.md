# Independent review of F1 transport changes

Reviewer: local_webkit_fix, 2026-10-22 UTC. The reviewer did not implement this transport patch. Reviewed the new read transport, handoff loader, deployment verifier, importer, observer, browser adapter changes and new transport tests against candidate b7747bf.

## Finding and resolution

**Resolved: internal RPC errors could hide a semantic rejection through failover.** The first patch categorically considered JSON-RPC error -32603 an availability failure. The independent synthetic reproduction returned a flat `execution reverted` error and an internal-error envelope containing a nested revert. Both caused a second provider to be queried and its `0x` result to be accepted. That contradicted the intended rule that semantic failures must not be retried until a different answer appears. Exact initial observation: `transport-semantic-review.json`.

The owner removed generic -32603 from the availability codes and added a conservative flat/nested semantic-error guard. Independent replay now throws at the primary endpoint for both cases without contacting the fallback. Exact replay: `transport-semantic-review-after.json`. The reviewer independently reran all 11 tests in `test-sdk/public-rpc.test.mjs`: PASS (`transport-independent-tests.log`). The owner expanded the existing table to cover generic internal errors and nested semantic errors mixed with an archive-looking message.

## Reviewed boundaries

- The importer emits `public-read-transport.json` in the SHA-256 asset inventory. The browser verifies inventory bytes before parsing its endpoint policy. A policy-byte mismatch fails before the runtime consumes its endpoints. The default compatibility fallback is a fixed application-code list plus the supplied primary, not a query-string/storage/user-input override.
- The official `network` and `walletAddChain` objects are copied unchanged. Transport policy contains only version, chain ID 1 and one to three credential-free HTTPS URLs. No signer, private backend or new account is introduced.
- The provider allowlist rejects account access, transaction submission and wallet methods before any request. Tracing allows only the native `callTracer` configuration. Requests and responses are size-bounded; endpoint count and per-fetch timeouts are bounded; cookies and redirects are disabled.
- Unsupported methods and explicit transport/archive availability failures can fall back. Wrong chain, malformed envelopes, semantic rejection, empty code, null receipts and returned trace errors cannot trigger a search for a more convenient successful answer. The patched -32603 cases are included in this boundary.
- The deployment-verifier diff adds a final receipt/block canonicality check. It does not remove source/build/ABI, exact CREATE, creation bytecode, constructor, historical/current runtime or immutable checks. The importer still authenticates frozen source bytes against the exact local source commit and writes the manifest only after verification.
- Only Ethereum uses the new browser transport. Local-chain transport and the selected wallet signing path remain separate and unchanged. Production gates are not opened by a successful transport read.

No further release-blocking finding was identified in this reviewed scope. This is a code/test review, not a cryptographic RPC proof or service-level guarantee. Future real deployment, final source pin, handoff import and final hosting-origin verification remain separate release gates. The final production export must be rebuilt after the resolved classifier change; the earlier fixture matrix did not exercise live public RPC calls.

## Final HTTP classifier review

The owner additionally fixed non-2xx responses carrying JSON-RPC semantic errors. The final reader bounds body size, parses JSON-RPC responses even when HTTP status is 500, validates identity, and checks error semantics before considering availability failover. Plain proxy/HTTP failures remain eligible; the observed PublicNode archive-tier HTTP 403 envelope is recognized narrowly. Empty/null error envelopes are rejected. The reviewer read this final implementation and independently reran the expanded **13/13** transport tests: PASS (`final-integration/transport-independent-tests.log`). Current frontend rebuilds include this final classifier.
