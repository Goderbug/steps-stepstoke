import { webkit, chromium } from '../source/frontend/node_modules/playwright-core/index.mjs';
import { writeFile } from 'node:fs/promises';
const base = '/Users/jc/Documents/ChatGPT/Rice/research/lineage-gate/release-preparation/overnight-release-v1/evidence/candidate-20261021T224531Z/frontend-review/browsers';
const rows=[];
for(const [engine,args] of [['webkit',[]],['chromium',[]]]){
 const b=await({webkit,chromium}[engine]).launch({executablePath:engine==='chromium'?`${base}/chromium-1248/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing`:undefined,args});
 try{for(const tabIndex of ['', ' tabindex="0"']){
  const p=await b.newPage();await p.setContent(`<html><body><a id="skip" href="#main"${tabIndex}>Skip to main content</a><button>Button</button><input><main id="main" tabindex="-1">Main</main><div id="region" tabindex="0" style="overflow:auto;width:200px"><table style="width:1000px"><tr><td>Wide</td></tr></table></div></body></html>`);
  await p.keyboard.press('Tab');const first=await p.evaluate(()=>({id:document.activeElement.id,tag:document.activeElement.tagName}));
  await p.locator('#region').focus();await p.keyboard.press('ArrowRight');await p.waitForTimeout(400);rows.push({engine,args,tabIndex,first,scrollLeft:await p.locator('#region').evaluate(e=>e.scrollLeft)});await p.close();
 }}finally{await b.close();}
}
await writeFile(new URL('./keyboard-diagnostic.json',import.meta.url),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
