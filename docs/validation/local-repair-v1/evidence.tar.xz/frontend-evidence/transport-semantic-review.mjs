import {createPublicReadProvider} from '../source/sdk/public-rpc.mjs';
import {writeFile} from 'node:fs/promises';
const urls=['https://primary.example/','https://fallback.example/'],cases=[];
for(const error of [{code:-32603,message:'execution reverted',data:'0x08c379a0'},{code:-32603,message:'Internal JSON-RPC error.',data:{code:3,message:'execution reverted',data:'0x08c379a0'}}]){
 const calls=[];
 const provider=createPublicReadProvider({rpcUrls:urls,fetch:async(url,init)=>{const req=JSON.parse(init.body);calls.push({url,method:req.method});return Response.json({jsonrpc:'2.0',id:req.id,...(req.method==='eth_chainId'?{result:'0x1'}:url===urls[0]?{error}:{result:'0x'})});}});
 let result,thrown;try{result=await provider.request({method:'eth_call',params:[{to:'0x1111111111111111111111111111111111111111',data:'0x'},'latest']});}catch(e){thrown=e.message;}
 cases.push({error,result,thrown,calls});
}
await writeFile(new URL(process.argv[2] ?? './transport-semantic-review.json',import.meta.url),JSON.stringify(cases,null,2));console.log(JSON.stringify(cases,null,2));
